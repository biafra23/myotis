package io.myotis.engine.ios

import io.myotis.engine.capi.MYOTIS_ABI_VERSION
import io.myotis.engine.capi.myotis_available_networks_json
import io.myotis.engine.capi.myotis_canonical_network_name
import io.myotis.engine.capi.myotis_check_raw_transaction_json
import io.myotis.engine.capi.myotis_create
import io.myotis.engine.capi.myotis_create_access_list_json
import io.myotis.engine.capi.myotis_debug_trace_call_json
import io.myotis.engine.capi.myotis_drain_logs
import io.myotis.engine.capi.myotis_ens_record_json
import io.myotis.engine.capi.myotis_estimate_gas_json
import io.myotis.engine.capi.myotis_estimate_gas_tx_json
import io.myotis.engine.capi.myotis_eth_call_json
import io.myotis.engine.capi.myotis_eth_call_overrides_json
import io.myotis.engine.capi.myotis_eth_call_tx_json
import io.myotis.engine.capi.myotis_fee_estimate_json
import io.myotis.engine.capi.myotis_fee_history_json
import io.myotis.engine.capi.myotis_get_block_by_hash_json
import io.myotis.engine.capi.myotis_get_block_by_number_json
import io.myotis.engine.capi.myotis_get_block_receipts_json
import io.myotis.engine.capi.myotis_get_code_json
import io.myotis.engine.capi.myotis_get_logs_json
import io.myotis.engine.capi.myotis_get_proof_json
import io.myotis.engine.capi.myotis_get_storage_at_json
import io.myotis.engine.capi.myotis_get_storage_proof_json
import io.myotis.engine.capi.myotis_get_raw_transaction_by_block_json
import io.myotis.engine.capi.myotis_get_raw_transaction_by_hash_json
import io.myotis.engine.capi.myotis_get_transaction_by_hash_json
import io.myotis.engine.capi.myotis_get_transaction_receipt_json
import io.myotis.engine.capi.myotis_import_log_index_files
import io.myotis.engine.capi.myotis_log_index_status_json
import io.myotis.engine.capi.myotis_read_stats_json
import io.myotis.engine.capi.myotis_set_log_index_config
import io.myotis.engine.capi.myotis_set_activity_watch
import io.myotis.engine.capi.myotis_address_activity_json
import io.myotis.engine.capi.myotis_send_raw_transaction_json
import io.myotis.engine.capi.myotis_set_boot_enodes
import io.myotis.engine.capi.myotis_init
import io.myotis.engine.capi.myotis_network_metering
import io.myotis.engine.capi.myotis_pause
import io.myotis.engine.capi.myotis_pending_nonce_overlay
import io.myotis.engine.capi.myotis_request_account_json
import io.myotis.engine.capi.myotis_resolve_block_hash_json
import io.myotis.engine.capi.myotis_resume
import io.myotis.engine.capi.myotis_accept_stale_anchor
import io.myotis.engine.capi.myotis_set_network_metering
import io.myotis.engine.capi.myotis_set_ws_bound_periods
import io.myotis.engine.capi.myotis_start
import io.myotis.engine.capi.myotis_status_json
import io.myotis.engine.capi.myotis_stop
import io.myotis.engine.capi.myotis_string_free
import kotlinx.cinterop.ByteVar
import kotlinx.cinterop.CPointer
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.toKString

/**
 * Thin Kotlin face over the Rust engine's C ABI — the iOS twin of
 * `RustEngineNative` on the JVM side. Owns exactly two concerns: the
 * string-memory contract (every `char*` the engine returns is copied to a
 * Kotlin String and immediately released via `myotis_string_free`) and the
 * ABI handshake. The JSON decoding and the lifecycle bookkeeping live above it:
 * in the typed API ([MyotisEngine], from `Myotis.newEngine()`), or in a host that
 * reads the JSON itself (`:app-ios`'s `IosNodeController`).
 *
 * All calls are BLOCKING (verified reads up to ~90 s) — callers stay off the
 * main thread, same rule as every other host.
 */
@OptIn(ExperimentalForeignApi::class)
object RustEngine {

    /** The ABI this host was built against, taken from the C header itself
     *  (`MYOTIS_ABI_VERSION` in rust/include/myotis_engine.h) rather than
     *  copied — the header instructs consumers to gate on the macro, and a
     *  capi.rs test pins it to `ABI_VERSION` in rust/myotis-engine/src/lib.rs.
     *  So there is no number to keep in sync here; cinterop reads it from the
     *  same header it generates these bindings from. The JVM twin
     *  `RustEngineNative.EXPECTED_ABI_VERSION` still mirrors by hand (UniFFI,
     *  no header in the loop). */
    const val EXPECTED_ABI_VERSION = MYOTIS_ABI_VERSION

    private val abiVersion: Int by lazy { myotis_init() }

    /**
     * Throws when the linked engine's ABI differs from what this host was built
     * against — fail loudly with a clear message instead of on drifted JSON or a
     * missing symbol. EVERY public entry point below calls this first (cheap
     * after the lazy first call), so no construction order can slip an FFI call
     * past the handshake — the header's contract is "refuse to call anything
     * else if the version differs".
     */
    fun requireAbi() {
        val v = abiVersion
        check(v == EXPECTED_ABI_VERSION) {
            "Rust engine ABI mismatch: expected $EXPECTED_ABI_VERSION, linked $v"
        }
    }

    /** Copy + free an engine-owned C string. Null stays null (the sentinel). */
    private fun take(p: CPointer<ByteVar>?): String? {
        if (p == null) return null
        return try {
            p.toKString()
        } finally {
            myotis_string_free(p)
        }
    }

    fun drainLogs(max: Int): String {
        requireAbi()
        return take(myotis_drain_logs(max)) ?: ""
    }

    fun availableNetworksJson(): String {
        requireAbi()
        return take(myotis_available_networks_json()) ?: "[]"
    }

    /** Canonical network name, or null for an unknown name/alias. */
    fun canonicalNetworkName(nameOrAlias: String): String? {
        requireAbi()
        return take(myotis_canonical_network_name(nameOrAlias))
    }

    /** Handle id (>= 1), or a negative sentinel (-1 create failed, -2 unsupported,
     *  -3 the dataDir is bound to a caller-supplied checkpoint — ABI 26's
     *  `myotis_create_with_checkpoint`, which this host does not wrap). */
    fun create(network: String, dataDir: String): Long {
        requireAbi()
        return myotis_create(network, dataDir)
    }

    fun start(handle: Long): Boolean {
        requireAbi()
        return myotis_start(handle)
    }

    fun stop(handle: Long) {
        requireAbi()
        myotis_stop(handle)
    }

    fun pause(handle: Long): Boolean {
        requireAbi()
        return myotis_pause(handle)
    }

    fun resume(handle: Long): Boolean {
        requireAbi()
        return myotis_resume(handle)
    }

    /** Override the weak-subjectivity anchor-age bound (periods; 0 = network
     *  default). Applied live — a STALE_ANCHOR park re-evaluates within a second. */
    fun setWsBoundPeriods(handle: Long, periods: Long): Boolean {
        requireAbi()
        return myotis_set_ws_bound_periods(handle, periods)
    }

    /** One-shot consent to sync forward from a stale anchor (this run only). */
    fun acceptStaleAnchor(handle: Long): Boolean {
        requireAbi()
        return myotis_accept_stale_anchor(handle)
    }

    /** Replace this handle's host-supplied EL seed pins (ABI >= 31, #465): a
     *  JSON array of `enode://` URLs, applied or refused as a whole — the
     *  contract is `myotis_set_boot_enodes` in `myotis_engine.h`. */
    fun setBootEnodes(handle: Long, enodesJson: String): Boolean {
        requireAbi()
        return myotis_set_boot_enodes(handle, enodesJson)
    }

    /** Install the eth_getLogs watch-list config; false = invalid/unavailable. */
    fun setLogIndexConfig(handle: Long, configJson: String): Boolean {
        requireAbi()
        return myotis_set_log_index_config(handle, configJson)
    }

    /** Log-index status JSON (enabled, counts, per-entry coverage); the JVM contract's
     *  stable "no index" object when the engine answers nothing. */
    fun logIndexStatusJson(handle: Long): String {
        requireAbi()
        return take(myotis_log_index_status_json(handle)) ?: """{"enabled":false,"logCount":0,"entries":[]}"""
    }

    /** Install the address-activity watch list (#691); false = refused/unavailable. */
    fun setActivityWatch(handle: Long, configJson: String): Boolean {
        requireAbi()
        return myotis_set_activity_watch(handle, configJson)
    }

    /** Address-activity JSON (#691), or an `{"error":...}` object; null only defensively,
     *  when no C string came back. */
    fun addressActivityJson(handle: Long, afterBlock: Long): String? {
        requireAbi()
        return take(myotis_address_activity_json(handle, afterBlock))
    }

    /** eth_getLogs over the watch-list index: the log array, or an `{"error":...}`
     *  object carrying the coverage or config detail, an unknown or stopped handle's
     *  ("node is not running") included; null only defensively, when no C string came back. */
    fun getLogsJson(handle: Long, filterJson: String): String? {
        requireAbi()
        return take(myotis_get_logs_json(handle, filterJson))
    }

    /** Read-fetch shadow-cache counters JSON (docs/read-stats.md). */
    fun readStatsJson(handle: Long): String {
        requireAbi()
        return take(myotis_read_stats_json(handle)) ?: """{"error":"engine returned no result"}"""
    }

    /** Import portable log-index snapshots ({"ok":...} / {"error":...}). */
    fun importLogIndexFiles(handle: Long, pathsJson: String): String {
        requireAbi()
        return take(myotis_import_log_index_files(handle, pathsJson))
            ?: """{"error":"engine returned no result"}"""
    }

    /** The host's word on the device's network (0 unknown, 1 unmetered, 2 metered). */
    fun setNetworkMetering(code: Int): Boolean {
        requireAbi()
        return myotis_set_network_metering(code)
    }

    fun networkMetering(): Int {
        requireAbi()
        return myotis_network_metering()
    }

    /** Status JSON object; `"{}"` for an unknown handle. */
    fun statusJson(handle: Long): String {
        requireAbi()
        return take(myotis_status_json(handle)) ?: "{}"
    }

    /** AccountProofResult JSON, or `{"error": ...}`; `block` (ABI >= 32) is the RPC
     *  selector the engine applies or refuses (the contract is `myotis_engine.h`'s). */
    fun requestAccountJson(handle: Long, address: String, block: String = ""): String {
        requireAbi()
        return take(myotis_request_account_json(handle, address, block))
            ?: """{"error":"engine returned no result"}"""
    }

    /** StorageProofResult JSON for storage [slot] of [address] — keyed by
     *  [holderOrNull] where the slot is an address-keyed mapping — or `{"error": ...}`. */
    fun getStorageProofJson(handle: Long, address: String, slot: Long, holderOrNull: String?): String =
        jsonCall { myotis_get_storage_proof_json(handle, address, slot, holderOrNull) }

    /** Generic ENS record dispatch (method + args in [paramsJson]). */
    fun ensRecordJson(handle: Long, paramsJson: String): String {
        requireAbi()
        return take(myotis_ens_record_json(handle, paramsJson))
            ?: """{"error":"engine returned no result"}"""
    }

    // ---- verified read surface behind the iOS JSON-RPC backend ----
    // Same envelopes as over JNI (golden-pinned): {"error"} for transport /
    // not-running, status-tagged objects for call/estimate, tri-state block/tx
    // JSON (object | the literal "null" | {"error"}).

    fun getCodeJson(handle: Long, address: String, block: String = ""): String =
        jsonCall { myotis_get_code_json(handle, address, block) }

    fun getStorageAtJson(handle: Long, address: String, position32Hex: String, block: String = ""): String =
        jsonCall { myotis_get_storage_at_json(handle, address, position32Hex, block) }

    /** eth_getProof (ABI 46): the EIP-1186 result object, `{"error"}` or the
     *  permanent `{"error","code":-32602}`. [keysJson] is the JSON array of
     *  storage keys as the request carried them; [block] a tag, a number or
     *  (ABI 47) a block hash. */
    fun getProofJson(handle: Long, address: String, keysJson: String, block: String = ""): String =
        jsonCall { myotis_get_proof_json(handle, address, keysJson, block) }

    fun ethCallJson(handle: Long, from: String, to: String, data: String, valueDecimal: String, block: String): String =
        jsonCall { myotis_eth_call_json(handle, from, to, data, valueDecimal, block) }

    /** [ethCallJson] with the `eth_call` state-override object as JSON (empty ⇒
     *  none). A SIMULATION over verified state — the caller's hypothesis, not a
     *  chain fact. */
    fun ethCallOverridesJson(
        handle: Long,
        from: String,
        to: String,
        data: String,
        valueDecimal: String,
        block: String,
        stateOverrides: String,
    ): String =
        jsonCall {
            myotis_eth_call_overrides_json(handle, from, to, data, valueDecimal, block, stateOverrides)
        }

    fun estimateGasJson(handle: Long, from: String, to: String, data: String, valueDecimal: String): String =
        jsonCall { myotis_estimate_gas_json(handle, from, to, data, valueDecimal) }

    /** `eth_estimateGas` for the FULL transaction object (ABI >= 34, #509): [txJson]
     *  is the router's canonical object, [block] the RPC selector, [stateOverrides]
     *  a state override object (empty ⇒ none). Every field is applied or the
     *  request refused with the permanent -32602 envelope. */
    fun estimateGasTxJson(handle: Long, txJson: String, block: String, stateOverrides: String): String =
        jsonCall { myotis_estimate_gas_tx_json(handle, txJson, block, stateOverrides) }

    /** `eth_call` for the FULL transaction object (ABI >= 35, #509): the arguments
     *  of [estimateGasTxJson]. Every field is applied or the request refused with
     *  the permanent -32602 envelope; a call that cannot succeed within the
     *  caller's gas, fee cap or funds is `{"status":"infeasible","reason"}`. */
    fun ethCallTxJson(handle: Long, txJson: String, block: String, stateOverrides: String): String =
        jsonCall { myotis_eth_call_tx_json(handle, txJson, block, stateOverrides) }

    /** `eth_createAccessList` for the FULL transaction object (ABI >= 40): the
     *  arguments of [estimateGasTxJson], the request checked as [ethCallTxJson]
     *  checks it. The list the transaction touches with the gas the run made
     *  with it used, and that run's own revert or halt next to them (`vmError`);
     *  every field applied or the request refused with the permanent -32602
     *  envelope. */
    fun createAccessListJson(handle: Long, txJson: String, block: String, stateOverrides: String): String =
        jsonCall { myotis_create_access_list_json(handle, txJson, block, stateOverrides) }

    /** `debug_traceCall` (ABI 54, #716): `{"status":"ok","trace":…}`, `infeasible`,
     *  `unavailable`, or the permanent -32602 envelope for a tracer or option this
     *  engine does not apply. */
    fun debugTraceCallJson(handle: Long, txJson: String, block: String, stateOverrides: String, tracerJson: String): String =
        jsonCall { myotis_debug_trace_call_json(handle, txJson, block, stateOverrides, tracerJson) }

    fun getBlockByNumberJson(handle: Long, blockTag: String, fullTransactions: Boolean): String =
        jsonCall { myotis_get_block_by_number_json(handle, blockTag, fullTransactions) }

    fun getBlockByHashJson(handle: Long, blockHash32Hex: String, fullTransactions: Boolean): String =
        jsonCall { myotis_get_block_by_hash_json(handle, blockHash32Hex, fullTransactions) }

    /** The canonical block a block hash names (ABI 47, #641): `{"hash","number"}`,
     *  the literal `"null"`, or an error envelope — header only. */
    fun resolveBlockHashJson(handle: Long, blockHash32Hex: String): String =
        jsonCall { myotis_resolve_block_hash_json(handle, blockHash32Hex) }

    fun getTransactionByHashJson(handle: Long, txHash32Hex: String): String =
        jsonCall { myotis_get_transaction_by_hash_json(handle, txHash32Hex) }

    /** A transaction's raw consensus bytes (ABI 53, #715): `"0x…"` as a JSON string,
     *  the literal `"null"`, or an error envelope. */
    fun getRawTransactionByHashJson(handle: Long, txHash32Hex: String): String =
        jsonCall { myotis_get_raw_transaction_by_hash_json(handle, txHash32Hex) }

    /** The raw bytes of the transaction at [index] of the block [selector] names (a
     *  tag, a 0x number or a 0x block hash; ABI 53, #715), as
     *  [getRawTransactionByHashJson]. */
    fun getRawTransactionByBlockJson(handle: Long, selector: String, index: Long): String =
        jsonCall { myotis_get_raw_transaction_by_block_json(handle, selector, index.toULong()) }

    fun getTransactionReceiptJson(handle: Long, txHash32Hex: String): String =
        jsonCall { myotis_get_transaction_receipt_json(handle, txHash32Hex) }

    fun getBlockReceiptsJson(handle: Long, selector: String): String =
        jsonCall { myotis_get_block_receipts_json(handle, selector) }

    /** Pending-tag nonce overlay; negative = malformed/not-running (serve the
     *  plain mined nonce). Plain long over the FFI — no JSON envelope. */
    fun pendingNonceOverlay(handle: Long, addressHex: String, minedNonce: Long): Long {
        requireAbi()
        return myotis_pending_nonce_overlay(handle, addressHex, minedNonce)
    }

    fun feeEstimateJson(handle: Long): String =
        jsonCall { myotis_fee_estimate_json(handle) }

    fun feeHistoryJson(handle: Long, blockCount: Long, newestBlockTag: String, percentilesJson: String): String =
        jsonCall { myotis_fee_history_json(handle, blockCount, newestBlockTag, percentilesJson) }

    fun sendRawTransactionJson(handle: Long, rawTxHex: String): String =
        jsonCall { myotis_send_raw_transaction_json(handle, rawTxHex) }

    /** The send gate on the bytes alone, no handle (ABI 45): `{"ok":true}`, the
     *  permanent `{"error","code":-32602}` refusal, or `{"error"}` for bad hex. */
    fun checkRawTransactionJson(rawTxHex: String): String =
        jsonCall { myotis_check_raw_transaction_json(rawTxHex) }

    private inline fun jsonCall(call: () -> CPointer<ByteVar>?): String {
        requireAbi()
        return take(call()) ?: """{"error":"engine returned no result"}"""
    }
}
