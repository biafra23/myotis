package io.myotis.api;

import java.util.List;

/**
 * One coherent point-in-time view of a network's stack — the superset of what the
 * hosts' status surfaces render (UI status tabs, the daemon's {@code status} /
 * {@code beacon-status} / {@code peers} IPC commands).
 *
 * @param running               whether the stack is running ({@code lifecycle == RUNNING})
 * @param lifecycle             coarse lifecycle state (paused ⇒ {@code running=false})
 * @param network               canonical network name
 * @param beaconState           beacon light-client state (STARTING before first state)
 * @param connectedPeers        EL peers with an open RLPx session (incl. still handshaking)
 * @param readyPeers            EL peers past the eth handshake
 * @param snapPeers             peers that negotiated snap (snap/1 or snap/2)
 * @param snapServingPeers      peers currently in the snap serving pool (drives readiness)
 * @param snap2ServingPeers     the part of {@code snapServingPeers} whose connection runs
 *                              snap/2 (EIP-8189); informational, never a readiness input
 * @param discoveredPeers       discv4 Kademlia table size
 * @param backedOffPeers        active (non-expired) dial-backoff entries, pruned on read
 * @param blacklistedPeers      peers blacklisted this session (wrong chain)
 * @param attemptedDials        in-flight / recently-attempted dials
 * @param discv5TableSize       live nodes in the CL discv5 routing table
 * @param executionBlockNumber  finalized execution block number (0 if none yet)
 * @param optimisticBlockNumber optimistic-head execution block number (0 if none yet)
 * @param finalizedSlot         finalized beacon slot (0 if none yet)
 * @param finalizedBlockNumber  execution block number of the finalized payload (0 if none)
 * @param syncStartPeriod       sync-committee catch-up start period (-1 if unknown)
 * @param syncCurrentPeriod     current sync-committee period the client holds
 * @param syncTargetPeriod      wall-clock sync-committee period (catch-up target)
 * @param finalizedPeriod       period of the finalized slot
 * @param wallClockPeriod       wall-clock period (== syncTargetPeriod; kept for
 *                              diagnostics parity with the daemon's beacon-status)
 * @param wsBoundPeriods        weak-subjectivity bound (sync-committee periods) the engine
 *                              enforces for this network — host override if set, else the
 *                              network default (see {@link BeaconState#STALE_ANCHOR})
 * @param verifiedHeadAgeMs     age of the last verified RPC head context;
 *                              {@code Long.MAX_VALUE} = none built yet
 * @param readyPeerList         per-peer detail for the READY peers, snap-capable first
 * @param pauseCount            times this stack entered idle sleep since start
 * @param totalPausedMs         cumulative time spent paused (ms), across all pauses
 * @param lastPauseEpochMs      wall-clock ms of the most recent pause; 0 if never paused
 * @param lastResumeEpochMs     wall-clock ms of the most recent DEMAND wake; 0 if none
 *                              (a foreground/observation wake does not update this)
 * @param lastWakeReason        {@link WakeReason} tag of the most recent demand wake; null if none
 * @param peerHeaderRequests    inbound GetBlockHeaders requests from peers this run
 * @param peerHeaderRequestsServed  of those, answered with at least one header
 * @param peerBodyRequests      inbound GetBlockBodies requests from peers this run
 * @param peerBodyRequestsServed    of those, answered with at least one body (always 0
 *                              today — a light client holds no bodies; requests get a
 *                              prompt empty response)
 * @param lcHunting             LC hunt engaged: the beacon light client is starved of
 *                              light-client servers and is aggressively discovering/probing
 *                              for new ones (bootstrap stall, starved catch-up, or finality
 *                              starvation)
 * @param elHunting             EL hunt engaged: the snap serving pool has been empty past
 *                              the stall window and the peer maintainer is in emergency
 *                              re-dial mode (backoff bypass for confirmed snap servers)
 * @param rpcPort               the JSON-RPC port this network's engine-owned listener was
 *                              CONFIGURED with; 0 = no listener configured (row hidden)
 * @param rpcServing            true = bound and serving on {@code 127.0.0.1:rpcPort};
 *                              false with a non-zero port = the bind failed or the
 *                              listener died (hosts render this as an error)
 * @param upgradeAdvisory       peers announce (or have already activated) a network
 *                              upgrade this build does not support — hosts tell the
 *                              user to update; null = none detected / watch not enabled
 *                              for this network. Advisory only (see {@link UpgradeAdvisory})
 * @param dataUsage             this network's bytes on the wire, since start and today
 *                              (see {@link DataUsage}); {@link DataUsage#NONE} when the
 *                              engine does not measure. Never null
 * @param networkMetering       the device network's metering as the host last reported
 *                              it ({@link MyotisEngine#setNetworkMetering}); engine-wide,
 *                              shown for debugging. Never null
 */
public record StatusSnapshot(
        boolean running,
        LifecycleState lifecycle,
        String network,
        BeaconState beaconState,
        int connectedPeers,
        int readyPeers,
        int snapPeers,
        int snapServingPeers,
        int snap2ServingPeers,
        int discoveredPeers,
        int backedOffPeers,
        int blacklistedPeers,
        int attemptedDials,
        int discv5TableSize,
        long executionBlockNumber,
        long optimisticBlockNumber,
        long finalizedSlot,
        long finalizedBlockNumber,
        long syncStartPeriod,
        long syncCurrentPeriod,
        long syncTargetPeriod,
        long finalizedPeriod,
        long wallClockPeriod,
        long verifiedHeadAgeMs,
        long wsBoundPeriods,
        List<PeerInfo> readyPeerList,
        int pauseCount,
        long totalPausedMs,
        long lastPauseEpochMs,
        long lastResumeEpochMs,
        String lastWakeReason,
        long peerHeaderRequests,
        long peerHeaderRequestsServed,
        long peerBodyRequests,
        long peerBodyRequestsServed,
        boolean lcHunting,
        boolean elHunting,
        int rpcPort,
        boolean rpcServing,
        UpgradeAdvisory upgradeAdvisory,
        DataUsage dataUsage,
        NetworkMetering networkMetering) {
}
