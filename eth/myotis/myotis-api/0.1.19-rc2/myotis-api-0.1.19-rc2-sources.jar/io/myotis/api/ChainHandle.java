package io.myotis.api;

/**
 * One hosted network's engine surface: lifecycle, live status, verified reads,
 * ENS, and the verified operator queries the desktop IPC / UIs are built on.
 *
 * <p>All methods are blocking — call from a worker thread. The long-running
 * verification queries are internally timeout-bounded (noted per method) and
 * return result records whose {@code failReason}/{@code error} fields describe
 * verification failures; they throw {@link EngineException} only for
 * programmer/state errors (bad address, network not running).
 */
public interface ChainHandle {

    /** Canonical network name this handle serves. */
    String networkName();

    /** The network's EVM chain id. */
    long chainId();

    /**
     * Build and start the stack. Blocking (DNS discovery + component startup,
     * typically a few seconds). Fault-isolated: on any failure the stack's
     * resources are closed and {@code false} is returned — never an exception,
     * and never an effect on sibling networks.
     */
    boolean start();

    /** Tear the stack down (reverse component order). Idempotent. */
    void stop();

    boolean isRunning();

    /**
     * Suspend all networking (zero sockets, zero periodic timers) while keeping
     * the stack instance and its warm verified state — beacon light-client
     * store, sync state, peer knowledge — in memory. The JSON-RPC server keeps
     * listening; a verified read arriving while paused triggers {@link #resume()}
     * and is held until the node can answer (bounded, ~90 s). Blocking (a few
     * seconds). Idempotent; a no-op unless {@code RUNNING}.
     *
     * @return {@code true} when the stack is {@code PAUSED} on return
     */
    boolean pause();

    /**
     * Rebuild networking after {@link #pause()}. Blocking (seconds; skips the
     * cold DNS walk). Fault-isolated like {@link #start()}: on failure returns
     * {@code false} and the stack stays {@code PAUSED} (retryable). A no-op
     * returning {@code true} when already {@code RUNNING}.
     */
    boolean resume();

    /**
     * As {@link #resume()}, but records {@code reason} (a {@link WakeReason} tag) as
     * the wake cause for the status screens' "last wake" line. {@link WakeReason#FOREGROUND}
     * is treated as an observation and does not overwrite the recorded last-wake reason.
     */
    boolean resume(String reason);

    /** Coarse lifecycle state; {@link #isRunning()} == {@code lifecycle() == RUNNING}. */
    LifecycleState lifecycle();

    /**
     * Epoch millis of the last host-relevant activity: any gated verified read
     * (JSON-RPC / ENS) or verified operator query. {@code 0} if none since
     * start. Hosts poll this for their idle-sleep timer — deliberately a getter
     * rather than a callback so the engine surface stays FFI-portable.
     */
    long lastActivityEpochMillis();

    /** Live-update the snap-peer maintainer target (no restart). */
    void setTargetSnapPeers(int target);

    /**
     * Live-update the eth/69 served-block window (no restart): how many recent block
     * headers this node retains and advertises as servable to peers via the EIP-7642
     * Status range / BlockRangeUpdate. Clamped by the engine at both ends
     * (currently [1, 4096]: 0 would disable serving; an unbounded window is an
     * archive-node promise a light client cannot keep).
     * Engines without an EL treat this as a no-op.
     */
    void setServedBlockWindow(int blocks);

    /**
     * Override the weak-subjectivity bound (in sync-committee periods) used to judge
     * whether the sync anchor — embedded checkpoint or persisted snapshot, whichever
     * is newer — is too old to be trusted. {@code 0} restores the network's built-in
     * default. Applied live: a stack parked in {@link BeaconState#STALE_ANCHOR}
     * re-evaluates and resumes syncing if the raised bound now covers the anchor's
     * age. Larger values weaken the long-range-attack guarantee — this is an
     * explicit operator knob, not a tuning parameter.
     */
    void setWsBoundPeriods(long periods);

    /**
     * Install the operator's web-page access policy on this network's JSON-RPC
     * listener (#502): which browser origins may use it. Applied live — the next
     * request is judged by it, no restart — and accepted before {@link #start()},
     * so the listener's very first request is already judged by the host's
     * setting (hosts set it between {@code create()} and {@code start()}, like
     * {@link #setServedBlockWindow}). Native wallets send no {@code Origin} and
     * are unaffected in every mode.
     *
     * @return the policy that now applies: the same mode, with the origins as the
     *         engine normalized them and WITHOUT any entry it could not read as an
     *         origin ({@code scheme://host[:port]}; no path, no wildcard). A caller
     *         that must not silently lose an entry compares it with what it asked
     *         for — the daemon refuses to boot on a difference, the apps log it.
     */
    WebAccessPolicy setWebAccessPolicy(WebAccessPolicy policy);

    /**
     * The web origins that tried to use this network's listener this run, most
     * recent first, with outcome, attempt count and last-seen time — the apps'
     * "recent web pages" list, from which a refused page is allowed with one
     * tap. In memory only (it is browsing history: never persisted, never served
     * over JSON-RPC) and bounded (the 50 most recent distinct origins).
     */
    java.util.List<WebOrigin> recentWebOrigins();

    /**
     * Consent to sync forward from an anchor older than the weak-subjectivity
     * bound. Run-sticky: it releases a stack parked in
     * {@link BeaconState#STALE_ANCHOR} and stays armed for any later stale-anchor
     * evaluation in the same run (e.g. a re-bootstrap after a discarded snapshot
     * resume) — it may also be armed before {@code start()} as deliberate
     * pre-consent. Never persisted: a restart with a still-stale anchor parks
     * again. Because arming is unconditional engine-side, interactive surfaces
     * should check the parked state before calling (the daemon's
     * {@code accept-stale-anchor} does; the apps' dialog leaves the screen when
     * the park releases).
     */
    void acceptStaleAnchor();

    /**
     * Clear the live dial bookkeeping — backoff entries and this session's
     * blacklist — so discovery re-dials from a fresh slate. On-disk peer-cache
     * FILES are host-owned; deleting those is the host's job.
     */
    void clearPeerState();

    /**
     * One coherent status snapshot including per-peer rows. Cheap to build;
     * suitable for polling at 1–2 s.
     */
    StatusSnapshot status();

    /** EL discovery's routing-table entries (operator diagnostics). Cheap. */
    java.util.List<DiscoveredPeer> discoveredPeers();

    /** All EL peers with an open RLPx session, including those still handshaking. Cheap. */
    java.util.List<ConnectedPeer> connectedPeers();

    /** Deep beacon/CL status including per-peer detail. Cheap. */
    BeaconStatus beaconStatus();

    /**
     * The verified eth_* read surface, or {@code null} until the handle can
     * answer: with a loopback listener attached (the Myotis apps), while the RPC
     * backend isn't started (e.g. the RPC port was unavailable at
     * {@link #start()}); with no listener (the engine library's in-process
     * consumer), before {@link #start()} succeeded.
     */
    VerifiedReads reads();

    /**
     * The name resolution surface, or {@code null} when this network has no name
     * registry (see {@link NetworkInfo#hasEns()}). ENS-shaped on every chain: on Gnosis
     * it serves Genome's {@code .gno} names, and refuses any other name.
     */
    EnsApi ens();

    // ---- verified operator queries ----

    /**
     * Fetch {@code hexAddress}'s account from a snap peer and run the full
     * verification ladder (proof-against-peer-root → beacon stateRootMatch →
     * BLS-attested headerChain). Blocking, bounded at ~90 s worst case.
     *
     * @throws EngineException on a malformed address or when not running
     */
    AccountProofResult requestAccount(String hexAddress);

    /**
     * Fetch and verify one storage slot of {@code hexAddress}. When
     * {@code holderHexOrNull} is set, the queried key is the Solidity mapping
     * slot {@code keccak256(holder ‖ slot)} (ERC-20 balance lookups). Blocking,
     * bounded at ~90 s worst case.
     *
     * @throws EngineException on malformed input or when not running
     */
    StorageProofResult getStorageProof(String hexAddress, long slot, String holderHexOrNull);

    /**
     * Fetch {@code count} consecutive block headers starting at
     * {@code startBlock} from a peer. Headers are integrity-checked (each hash
     * is recomputed); chain-of-custody verification against the beacon anchor is
     * the caller's concern ({@link #getBlockVerified} does it for one block).
     * Blocking, bounded at ~30 s.
     */
    HeadersResult getHeaders(long startBlock, int count);

    /**
     * Fetch one block (header + body summary) and verify it against the beacon
     * chain: a parent-hash header-chain walk from the block UP to a beacon-attested
     * block hash at or above it (≤ 8192 blocks), which must prove this very header.
     * Blocking, bounded at ~90 s.
     */
    BlockResult getBlockVerified(long blockNumber);

    /**
     * Install the opt-in eth_getLogs watch-list config as JSON
     * ({@code {"enabled":bool,"watch":[{"address","fromBlock","topic0s"?}],
     * "unwatch":["0x…"]?}}). {@code watch} is ADDITIVE: it is unioned with what
     * the index already subscribes, so an address left out of it stays indexed.
     * {@code unwatch} is the unsubscribe — each address it names leaves the
     * index before the union, with its coverage and its stored logs, while the
     * other entries keep theirs; an address the index does not watch is
     * ignored, and one listed under both keys refuses the push. On the Rust
     * engine (ABI 48) an entry may name a 32-byte {@code "topic"} (with
     * {@code "positions"}, 1–3) in place of {@code "address"}: every log from
     * any emitter carrying that value there, and {@code unwatch} takes such
     * values too (docs/eth-getlogs-design.md §6). {@code true}
     * means the push is done and its unwatch durable; {@code false} also
     * covers an unwatch whose checkpoint could not be written (repeat the
     * push).
     * Default false: the Java engine has no log index (its verified getLogs
     * answers the strict cannot-serve), so hosts may call this unconditionally.
     */
    default boolean setLogIndexConfig(String configJson) {
        return false;
    }

    /**
     * Log-index status JSON (enabled flag, log count, backfill cursor,
     * per-entry covered spans). Default: a stable "no index" object.
     */
    default String logIndexStatusJson() {
        return "{\"enabled\":false,\"logCount\":0,\"entries\":[]}";
    }

    /**
     * Install the address-activity watch list (#691) as JSON
     * ({@code {"watch":["0x…"]?,"unwatch":["0x…"]?}}): drop {@code unwatch},
     * then add {@code watch}. ADDITIVE like {@link #setLogIndexConfig}: an
     * address left out of {@code watch} stays watched. The engine follows
     * verified heads for activity only while the list is non-empty, and keeps
     * it across a pause and resume of this chain, not across a restart.
     * {@code false} = refused, nothing changed: malformed JSON, an entry that
     * is not a 20-byte hex address, an address under both keys, a
     * {@code watch} naming more than 256 addresses or a list that would exceed
     * 256 ({@code unwatch} of any length is accepted), or a chain that is not
     * running (paused included: push again). Default false: no activity
     * follower on this engine — tell that apart from a paused chain by
     * {@link #addressActivityJson} answering {@code null}, and do not retry.
     */
    default boolean setActivityWatch(String configJson) {
        return false;
    }

    /**
     * Which watched addresses the verified blocks after {@code afterBlock}
     * touched (#691), answered from what the follower kept, with no I/O:
     * {@code {"from","to","base":{"block","hash"|null},"gaps":{"account":[[a,b]…],
     * "log":[[a,b]…]},"touched":[{"address","block","blockHash","via":["account"?,"log"?]}…],
     * "watching":["0x…"…]}}. Every block of {@code [from, to]} (to = the
     * verified head) is covered or listed in {@code gaps}, per kind; a block
     * the follower did not check is a gap, never a silence. {@code "log"} is
     * the header's logs bloom: a watched address absent from {@code touched}
     * for a log-covered block is named by no log of it, as emitter or indexed
     * topic (a hit may be a false positive), which says nothing of a change no
     * such log names, such as a rebasing token's. {@code "account"} is the
     * account's own state — a balance, nonce or code change, or a storage
     * write — from the block's access list (EIP-7928), verified against the
     * header's commitment: definitive where covered. A block whose list no
     * peer served, or one before Amsterdam, is an account gap. Above finality a block can come back with a new
     * {@code blockHash}. {@code {"error":…}} when the chain is not running
     * (paused included) or its light client has anchored no head yet.
     * Default {@code null}: no activity follower on this engine.
     */
    default String addressActivityJson(long afterBlock) {
        return null;
    }

    /**
     * Read-fetch shadow-cache counters as JSON (schema 1; docs/read-stats.md):
     * how much of this chain's verified account / storage / bytecode fetch
     * traffic a cache — and which keying — would have served, with the
     * wall-clock it would have saved. A measurement surface: nothing is ever
     * served from it. Not gated on readiness (a status probe, like
     * {@link #logIndexStatusJson}); engines answer {@code {"error":...}} when
     * they cannot. Default: that same error shape, for a handle that does not
     * measure — never a partial schema-1 object, which a consumer could not
     * tell from a real one.
     */
    default String readStatsJson() {
        return "{\"error\":\"read stats not measured by this engine\"}";
    }

    /**
     * Import portable log-index snapshot files: {@code pathsJson} is a JSON
     * array of absolute file paths, each a self-describing snapshot of this
     * chain (produced by the daemon's {@code build-logindex} tool or another
     * node's export). All-or-nothing merge into the node's index; importing
     * is the opt-in, so catch-up for every imported address starts
     * immediately. Returns {@code {"ok":true,"status":...}} or
     * {@code {"error":...}}. Default: a stable not-supported error (the Java
     * engine has no log index).
     */
    default String importLogIndexFiles(String pathsJson) {
        return "{\"error\":\"log-index import is not supported by this engine\"}";
    }

    /**
     * Export the current log index as a portable snapshot file at
     * {@code path} (finality-clamped, self-describing — importable via
     * {@link #importLogIndexFiles} anywhere on the same chain; partial
     * coverage exports honestly, the importer's catch-up finishes the walk).
     * Returns {@code {"ok":true}} or {@code {"error":...}}. Default: a
     * stable not-supported error (the Java engine has no log index).
     */
    default String exportLogIndex(String path) {
        return "{\"error\":\"log-index export is not supported by this engine\"}";
    }

    /**
     * Dial one specific EL peer by endpoint + secp256k1 public key (operator
     * debugging). Returns immediately after the connect is initiated.
     *
     * @throws EngineException on a malformed pubkey or when not running
     */
    DialResult dialPeer(String host, int port, String pubkeyHex);
}
