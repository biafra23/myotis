package io.myotis.engines.rust;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import uniffi.myotis_engine.Myotis_engineKt;

/**
 * The FFI boundary to {@code libmyotis_engine} ({@code rust/myotis-engine}), since the
 * UniFFI migration a thin STATIC DELEGATOR over the generated Kotlin bindings
 * ({@code uniffi.myotis_engine} — committed at src/main/kotlin, regenerated via the
 * root {@code uniffiGenerateKotlin} task). Compound values still cross as JSON strings
 * (transport swap only — the hand-JNI is gone but the shapes are unchanged and stay
 * pinned by the golden tests on both sides).
 *
 * <p>Availability = the bindings initialized (UniFFI verifies a per-function API
 * checksum against the loaded library — the stale-.so guard is now structural) AND
 * {@link #nativeInit()} returned the coarse ABI version this class was compiled
 * against (kept as a belt-and-braces check + the log line).
 *
 * <p>Load order: an explicit absolute path in {@code -Dmyotis.engine.lib=...} (how the
 * desktop `run` task injects the dev build) is forwarded to the bindings via UniFFI's
 * {@code uniffi.component.myotis_engine.libraryOverride} property; otherwise JNA
 * resolves {@code myotis_engine} from {@code jna.library.path} + system paths — it
 * does NOT consult {@code java.library.path}, so {@link #load()} mirrors that
 * property into {@code jna.library.path} when the latter is unset (the daemon's run
 * task and the module's tests point java.library.path at the cargo build dir). A
 * host that sets {@code jna.library.path} itself owns the full search path. On
 * Android JNA resolves the bundled jniLibs on its own.
 *
 * <p>Every method keeps the old hand-JNI null tolerance: null String arguments are
 * normalized to {@code ""} (the Rust side used {@code unwrap_or_default}) — except
 * the genuinely optional {@code holderOrNull}, which maps to Kotlin's {@code String?}.
 */
final class RustEngineNative {

    private static final Logger log = LoggerFactory.getLogger(RustEngineNative.class);

    /** Must match {@code ABI_VERSION} in rust/myotis-engine/src/lib.rs. */
    static final int EXPECTED_ABI_VERSION = 55; // 55: simulate_v1_json (#716); 54: debug_trace_call_json (#716); 53: get_raw_transaction_by_hash_json + get_raw_transaction_by_block_json (#715); 52: account and call JSON carry the proven blockHash; 51: set_activity_watch + address_activity_json (#691); 50: dataUsage + networkMetering in the status, set_network_metering; 49: ens offchain envelope carries reverseClaim; 48: log-index topic entries (#673); 47: resolve_block_hash_json, get_proof_json takes a block hash; 46: get_proof_json; 45: check_raw_transaction_json; 44: send_raw_transaction_json refuses non-transactions (-32602)

    private static final boolean AVAILABLE = load();

    private RustEngineNative() {}

    static boolean isAvailable() {
        return AVAILABLE;
    }

    private static boolean load() {
        String explicit = System.getProperty("myotis.engine.lib");
        if (explicit != null && !explicit.isBlank()) {
            // Forward the dev-build path to the generated bindings' loader. Set-if-absent
            // so an explicitly configured override always wins.
            if (System.getProperty("uniffi.component.myotis_engine.libraryOverride") == null) {
                System.setProperty("uniffi.component.myotis_engine.libraryOverride", explicit);
            }
        } else if (System.getProperty("jna.library.path") == null) {
            // JNA searches jna.library.path (plus system paths), NOT java.library.path —
            // which is where the daemon's run task and :myotis-engine-rust's test task put the
            // cargo build dir. Mirror it so the pre-UniFFI lookup contract keeps holding.
            // (Android ignores this: JNA resolves bundled jniLibs on its own.)
            String jlp = System.getProperty("java.library.path");
            if (jlp != null && !jlp.isBlank()) {
                System.setProperty("jna.library.path", jlp);
            }
        }
        try {
            // Run UniFFI's integrity gate FIRST: uniffiEnsureInitialized() loads the
            // library and validates the bindings-contract version plus a per-function
            // API checksum against the loaded .so. It must be called explicitly —
            // plain binding calls like engineInit() register the functions WITHOUT
            // checksum validation, so skipping this line would let a reshaped symbol
            // segfault at first use instead of failing loudly here.
            Myotis_engineKt.uniffiEnsureInitialized();
            int abi = Myotis_engineKt.engineInit();
            if (abi != EXPECTED_ABI_VERSION) {
                log.warn("[engines] libmyotis_engine ABI {} != expected {} (stale library?); "
                        + "Rust engine unavailable", abi, EXPECTED_ABI_VERSION);
                return false;
            }
        } catch (UnsatisfiedLinkError e) {
            // The normal cargo-less case: no library on the search path (or one so old
            // it predates UniFFI and lacks the uniffi_* symbols entirely).
            log.info("[engines] libmyotis_engine not loaded ({}); Rust engine unavailable",
                    e.toString());
            return false;
        } catch (Throwable t) {
            // Library FOUND but failed UniFFI's contract/checksum validation (stale or
            // reshaped .so) — louder than the missing-library case on purpose. The
            // bindings run those checks in a static initializer, so what arrives here is
            // usually an ExceptionInInitializerError that says nothing by itself: name its
            // cause, and log the trace (the trailing throwable) for anything else.
            Throwable reason = t instanceof ExceptionInInitializerError && t.getCause() != null
                    ? t.getCause() : t;
            log.warn("[engines] libmyotis_engine failed UniFFI validation ({}); "
                    + "Rust engine unavailable — rebuild the library (cargoBuildHost / "
                    + "cargoNdkAndroid) or regenerate the bindings (uniffiGenerateKotlin)",
                    reason.toString(), t);
            return false;
        }
        log.info("[engines] libmyotis_engine loaded via UniFFI (ABI {})", EXPECTED_ABI_VERSION);
        return true;
    }

    private static String nz(String s) {
        return s == null || !wellFormed(s) ? "" : s;
    }

    /** The old hand-JNI surface degraded malformed UTF-16 (unpaired surrogates —
     *  attacker-reachable via JSON-RPC string params) to an absent/empty string on
     *  the Rust side (CESU-8 decode failure → {@code unwrap_or_default}). The
     *  generated bindings instead throw {@code MalformedInputException} from their
     *  UTF-8 lowering; probe first so the pre-UniFFI semantics keep holding.
     *
     *  <p>Hand-rolled surrogate-pairing scan rather than {@code CharsetEncoder.canEncode}:
     *  this runs on every FFI string argument, and the encoder probe allocates per call.
     *  The O(n) walk itself is inherent to validating (the bindings' UTF-8 lowering
     *  re-scans the same chars right after). */
    private static boolean wellFormed(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isHighSurrogate(c)) {
                if (i + 1 >= s.length() || !Character.isLowSurrogate(s.charAt(i + 1))) {
                    return false;
                }
                i++; // consume the low half of a well-formed pair
            } else if (Character.isLowSurrogate(c)) {
                return false; // low surrogate with no preceding high
            }
        }
        return true;
    }

    /** ABI handshake; returns the library's compiled-in ABI version. */
    static int nativeInit() {
        return Myotis_engineKt.engineInit();
    }

    /** {@code nativeCreate} sentinel: the network is canonical but this engine
     *  doesn't host it yet (must match {@code UNSUPPORTED_NETWORK} in
     *  rust/myotis-engine/src/host.rs). */
    static final long UNSUPPORTED_NETWORK = -2;
    /** The dataDir is bound to a checkpoint the host supplied through the plain-C /
     *  Node {@code myotis_create_with_checkpoint} (ABI 26, {@code sync-anchor[-net].json}
     *  next to the snapshot). The JVM has no wrapper for that path and must never resume
     *  such a directory from the embedded anchor — see {@link RustMyotisEngine}. Must
     *  match {@code ANCHOR_MISMATCH} in rust/myotis-engine/src/host.rs. */
    static final long ANCHOR_MISMATCH = -3;

    /** The embedded network catalog as a JSON array of NetworkInfo objects. */
    static String nativeAvailableNetworksJson() {
        return Myotis_engineKt.availableNetworksJson();
    }

    /** Canonical name for a name/alias, or null when unknown. */
    static String nativeCanonicalNetworkName(String nameOrAlias) {
        if (nameOrAlias == null) return null;
        return Myotis_engineKt.canonicalNetworkName(nz(nameOrAlias));
    }

    // ---- Hosting surface. See RustChainHandle / RustMyotisEngine. ----

    /** Allocate a not-yet-started handle (id ≥ 1, or a negative failure sentinel). */
    static long nativeCreate(String network, String dataDir) {
        if (network == null) return -1;
        // nz also degrades malformed UTF-16 to "" → unknown network → CREATE_FAILED,
        // the old shim's behavior.
        return Myotis_engineKt.createHandle(nz(network), nz(dataDir));
    }

    /** Start the sync loop for a created handle. True on success. */
    static boolean nativeStart(long handle) {
        return Myotis_engineKt.startHandle(handle);
    }

    /**
     * Toggle Tor verified-read routing (docs/privacy-and-tor.md). Returns true iff
     * the loaded library was built with Tor support ({@code --features tor}); a
     * Tor-less library returns false and no-ops. Process-global, not per-handle.
     */
    static boolean nativeSetTorEnabled(boolean on) {
        return Myotis_engineKt.setTorEnabled(on);
    }

    /**
     * Tor status bitmask for the Status view: bit0 compiled-in, bit1 enabled,
     * bit2 bootstrapped (circuit ready). {@code 0} = no Tor support in this build.
     */
    static int nativeTorStatus() {
        return Myotis_engineKt.torStatus();
    }

    /**
     * Name the absolute directories the embedded Tor client keeps its state and
     * directory cache in (required on Android before the first Tor read). True iff
     * the client will use exactly these; false for a relative path, a different pair
     * once a bootstrap holds its directories, or a Tor-less library.
     */
    static boolean nativeSetTorStorageDirs(String stateDir, String cacheDir) {
        // nz(): null or malformed UTF-16 becomes "", which the engine refuses (not absolute).
        return Myotis_engineKt.setTorStorageDirs(nz(stateDir), nz(cacheDir));
    }

    /**
     * Allow or forbid EIP-1459 DNS discovery — the EL node lists, walked over the
     * system resolver (#539) — for every network this process runs. Off until a
     * host switches it on; never used while Tor is enabled. Returns the state now
     * in force. Process-global, not per-handle.
     */
    static boolean nativeSetDnsDiscovery(boolean on) {
        return Myotis_engineKt.setDnsDiscovery(on);
    }

    /**
     * The host's word on the device's current network, for the status JSON's data
     * usage (docs/data-usage.md): 0 unknown, 1 unmetered, 2 metered. False, and
     * nothing recorded, for any other code. Process-global, not per-handle.
     */
    static boolean nativeSetNetworkMetering(int code) {
        return Myotis_engineKt.setNetworkMetering(code);
    }

    /** The metering code last recorded (0 until a host reports one). */
    static int nativeNetworkMetering() {
        return Myotis_engineKt.networkMetering();
    }

    /** One handle's status as a JSON object, or {@code "{}"} for an unknown handle. */
    static String nativeStatusJson(long handle) {
        return Myotis_engineKt.statusJson(handle);
    }

    /** Remove and shut down a handle's sync loop. No-op for an unknown id. */
    static void nativeStop(long handle) {
        Myotis_engineKt.stopHandle(handle);
    }

    // ---- Idle-sleep surface. See RustChainHandle. ----

    /** Idle-sleep a RUNNING handle; true ONLY on an actual RUNNING→PAUSED transition. */
    static boolean nativePause(long handle) {
        return Myotis_engineKt.pauseHandle(handle);
    }

    /** Rebuild networking for a PAUSED handle; true ONLY on PAUSED→RUNNING. */
    static boolean nativeResume(long handle) {
        return Myotis_engineKt.resumeHandle(handle);
    }

    /**
     * Live-set the eth/69 served-block window (Settings knob). Applied live on a
     * RUNNING handle; stashed and applied at the next start otherwise. False
     * only for an unknown handle.
     */
    static boolean nativeSetServedBlockWindow(long handle, int blocks) {
        return Myotis_engineKt.setServedBlockWindow(handle, blocks);
    }

    /**
     * Override the weak-subjectivity anchor-age bound (periods); 0 restores the
     * network default. Applied live — a handle parked in STALE_ANCHOR
     * re-evaluates within a second. False only for an unknown handle.
     */
    static boolean nativeSetWsBoundPeriods(long handle, long periods) {
        return Myotis_engineKt.setWsBoundPeriods(handle, periods);
    }

    /**
     * One-shot consent to sync forward from a stale anchor — releases a
     * STALE_ANCHOR park for the rest of this run; never persisted. False only
     * for an unknown handle.
     */
    static boolean nativeAcceptStaleAnchor(long handle) {
        return Myotis_engineKt.acceptStaleAnchor(handle);
    }

    /** Up to {@code max} buffered engine tracing lines (oldest first, newline-joined). */
    static String nativeDrainLogs(int max) {
        return Myotis_engineKt.drainLogs(max);
    }

    // ---- EL verified-read surface. See RustChainHandle for the JSON contracts. ----

    /** Verified account query as JSON (AccountProofResult shape / {@code error} object);
     *  {@code block} is the RPC block selector the engine applies or refuses (ABI >= 32:
     *  the contract is {@code myotis_engine.h}'s). */
    static String nativeRequestAccountJson(long handle, String address, String block) {
        return Myotis_engineKt.requestAccountJson(handle, nz(address), nz(block));
    }

    /** Verified storage-slot query as JSON; non-null {@code holderOrNull} selects the
     *  ERC-20 mapping key {@code keccak256(pad32(holder) ‖ uint256(slot))}. */
    static String nativeGetStorageProofJson(
            long handle, String address, long slot, String holderOrNull) {
        // Malformed holder → null, matching the old shim (decode failure → None).
        String holder = (holderOrNull != null && wellFormed(holderOrNull)) ? holderOrNull : null;
        return Myotis_engineKt.getStorageProofJson(handle, nz(address), slot, holder);
    }

    /** Verified contract-code query (`eth_getCode`) as JSON. */
    static String nativeGetCodeJson(long handle, String address, String block) {
        return Myotis_engineKt.getCodeJson(handle, nz(address), nz(block));
    }

    /** Verified RAW-32-byte-position storage query (`eth_getStorageAt`) as JSON. */
    static String nativeGetStorageAtJson(long handle, String address, String position, String block) {
        return Myotis_engineKt.getStorageAtJson(handle, nz(address), nz(position), nz(block));
    }

    /** {@code eth_getProof} (ABI 46) as JSON: the result object, {@code {"error"}} or
     *  {@code {"error","code":-32602}}; {@code keysJson} is the JSON array of storage
     *  keys as the request carried them; {@code block} is held to the proof pin rules. */
    static String nativeGetProofJson(long handle, String address, String keysJson, String block) {
        return Myotis_engineKt.getProofJson(handle, nz(address), nz(keysJson), nz(block));
    }

    /** Verified {@code eth_call} over the revm executor, as JSON. */
    static String nativeEthCallJson(
            long handle, String from, String to, String data, String value, String block) {
        return Myotis_engineKt.ethCallJson(
                handle, nz(from), nz(to), nz(data), nz(value), nz(block));
    }

    /**
     * {@link #nativeEthCallJson} with the {@code eth_call} state-override object
     * as JSON (empty ⇒ none). The result is a SIMULATION over verified state,
     * not a chain fact.
     */
    static String nativeEthCallOverridesJson(
            long handle,
            String from,
            String to,
            String data,
            String value,
            String block,
            String stateOverrides) {
        return Myotis_engineKt.ethCallOverridesJson(
                handle, nz(from), nz(to), nz(data), nz(value), nz(block), nz(stateOverrides));
    }

    /** Verified {@code eth_estimateGas} over the revm executor, as JSON. */
    static String nativeEstimateGasJson(
            long handle, String from, String to, String data, String value) {
        return Myotis_engineKt.estimateGasJson(handle, nz(from), nz(to), nz(data), nz(value));
    }

    /**
     * Verified {@code eth_estimateGas} for the FULL transaction object (ABI >= 34,
     * #509) — {@code tx} is the canonical JSON the router built, {@code block} the
     * RPC block selector, {@code stateOverrides} a state override object (empty ⇒
     * none). Every field is applied or the request refused (-32602).
     */
    static String nativeEstimateGasTxJson(long handle, String tx, String block, String stateOverrides) {
        return Myotis_engineKt.estimateGasTxJson(handle, nz(tx), nz(block), nz(stateOverrides));
    }

    /**
     * Verified {@code eth_call} for the FULL transaction object (ABI >= 35,
     * #509) — the arguments of {@link #nativeEstimateGasTxJson}. Every field is
     * applied or the request refused (-32602).
     */
    static String nativeEthCallTxJson(long handle, String tx, String block, String stateOverrides) {
        return Myotis_engineKt.ethCallTxJson(handle, nz(tx), nz(block), nz(stateOverrides));
    }

    /**
     * Verified {@code eth_createAccessList} for the FULL transaction object (ABI
     * >= 40) — the arguments of {@link #nativeEstimateGasTxJson}. The list the
     * transaction touches with the gas the run made with it used, and that run's
     * own revert or halt next to them; every field is applied or the request
     * refused (-32602).
     */
    static String nativeCreateAccessListJson(long handle, String tx, String block, String stateOverrides) {
        return Myotis_engineKt.createAccessListJson(handle, nz(tx), nz(block), nz(stateOverrides));
    }

    /** Verified ENS forward resolution (name → address record), as JSON. */
    static String nativeResolveEnsJson(long handle, String name) {
        return Myotis_engineKt.resolveEnsJson(handle, nz(name));
    }

    /** One generic ENS record dispatch; method + args travel in {@code paramsJson}. */
    static String nativeEnsRecordJson(long handle, String paramsJson) {
        return Myotis_engineKt.ensRecordJson(handle, nz(paramsJson));
    }

    /** Verified {@code eth_getBlockByNumber} (block JSON / literal "null" / error). */
    static String nativeGetBlockByNumberJson(
            long handle, String blockTag, boolean fullTransactions) {
        return Myotis_engineKt.getBlockByNumberJson(handle, nz(blockTag), fullTransactions);
    }

    /** Verified fee suggestion (`eth_gasPrice` + `eth_maxPriorityFeePerGas`), as JSON. */
    static String nativeFeeEstimateJson(long handle) {
        return Myotis_engineKt.feeEstimateJson(handle);
    }

    /** Gossip a signed raw tx; {@code {"txHash":"0x…"}}, {@code {"status":"rejected","reason"}}
     *  (ABI 36: refused before broadcast, geth's txpool verdict) or an error object. */
    static String nativeSendRawTransactionJson(long handle, String rawTxHex) {
        return Myotis_engineKt.sendRawTransactionJson(handle, nz(rawTxHex));
    }

    /** The send gate on the bytes alone, no handle (ABI 45): {@code {"ok":true}}, the
     *  permanent {@code {"error","code":-32602}} refusal, or an error object for bad hex. */
    static String nativeCheckRawTransactionJson(String rawTxHex) {
        return Myotis_engineKt.checkRawTransactionJson(nz(rawTxHex));
    }

    /** Verified {@code eth_getTransactionReceipt} (receipt JSON / "null" / error). */
    static String nativeGetTransactionReceiptJson(long handle, String txHashHex) {
        return Myotis_engineKt.getTransactionReceiptJson(handle, nz(txHashHex));
    }

    /** The "pending" nonce overlay; negative only for malformed input / missing handle. */
    static long nativePendingNonceOverlay(long handle, String addressHex, long minedNonce) {
        return Myotis_engineKt.pendingNonceOverlay(handle, nz(addressHex), minedNonce);
    }

    /** Verified {@code eth_getTransactionByHash} (tx JSON / "null" / error). */
    static String nativeGetTransactionByHashJson(long handle, String txHashHex) {
        return Myotis_engineKt.getTransactionByHashJson(handle, nz(txHashHex));
    }

    /** {@code debug_traceCall} (ABI 54, #716): the trace JSON, infeasible, unavailable,
     *  or the permanent -32602 envelope. */
    static String nativeDebugTraceCallJson(long handle, String txJson, String block, String stateOverrides,
                                           String tracerJson) {
        return Myotis_engineKt.debugTraceCallJson(handle, nz(txJson), nz(block), nz(stateOverrides), nz(tracerJson));
    }

    /** {@code eth_simulateV1} (ABI 55, #716): geth's result, geth's own simulation error,
     *  unavailable, or the permanent -32602 envelope. */
    static String nativeSimulateV1Json(long handle, String optsJson, String block) {
        return Myotis_engineKt.simulateV1Json(handle, nz(optsJson), nz(block));
    }

    /** Verified {@code eth_getRawTransactionByHash} (ABI 53, #715): {@code "0x…"} as a JSON
     *  string, the {@code "null"} literal, or an error envelope. */
    static String nativeGetRawTransactionByHashJson(long handle, String txHashHex) {
        return Myotis_engineKt.getRawTransactionByHashJson(handle, nz(txHashHex));
    }

    /** Verified {@code eth_getRawTransactionByBlock{Number,Hash}AndIndex} (ABI 53, #715):
     *  {@code selector} is a tag, a 0x number or a 0x block hash. */
    static String nativeGetRawTransactionByBlockJson(long handle, String selector, long index) {
        return Myotis_engineKt.getRawTransactionByBlockJson(handle, nz(selector), index);
    }

    /** The canonical block a block hash names (ABI 47, #641): {@code {"hash","number"}},
     *  the {@code "null"} literal, or an error envelope — header only. */
    static String nativeResolveBlockHashJson(long handle, String blockHashHex) {
        return Myotis_engineKt.resolveBlockHashJson(handle, nz(blockHashHex));
    }

    /** Verified {@code eth_getBlockByHash} (block JSON / "null" / error). */
    static String nativeGetBlockByHashJson(
            long handle, String blockHashHex, boolean fullTransactions) {
        return Myotis_engineKt.getBlockByHashJson(handle, nz(blockHashHex), fullTransactions);
    }

    /** Verified {@code eth_getBlockReceipts} (receipts array JSON / "null" / error). */
    static String nativeGetBlockReceiptsJson(long handle, String selector) {
        return Myotis_engineKt.getBlockReceiptsJson(handle, nz(selector));
    }

    /** {@code eth_getLogs} over the watch-list index (array / {"error":...}). */
    static String nativeGetLogsJson(long handle, String filterJson) {
        return Myotis_engineKt.getLogsJson(handle, nz(filterJson));
    }

    /** Install the log-index watch-list config; false = invalid/unavailable. */
    static boolean nativeSetLogIndexConfig(long handle, String configJson) {
        return Myotis_engineKt.setLogIndexConfig(handle, nz(configJson));
    }

    /** Log-index status JSON (enabled, counts, coverage per entry). */
    static String nativeLogIndexStatusJson(long handle) {
        return Myotis_engineKt.logIndexStatusJson(handle);
    }

    /** Install the address-activity watch list (#691); false = refused/unavailable. */
    static boolean nativeSetActivityWatch(long handle, String configJson) {
        return Myotis_engineKt.setActivityWatch(handle, nz(configJson));
    }

    /** Address-activity JSON (#691; {"error":...} when not running). */
    static String nativeAddressActivityJson(long handle, long afterBlock) {
        return Myotis_engineKt.addressActivityJson(handle, afterBlock);
    }

    /** Read-fetch shadow-cache counters JSON (docs/read-stats.md). */
    static String nativeReadStatsJson(long handle) {
        return Myotis_engineKt.readStatsJson(handle);
    }

    /** Import portable log-index snapshots ({"ok":true,...} / {"error":...}). */
    static String nativeImportLogIndexFiles(long handle, String pathsJson) {
        return Myotis_engineKt.importLogIndexFiles(handle, nz(pathsJson));
    }

    /** Export the log index as a portable snapshot ({"ok":true} / {"error":...}). */
    static String nativeExportLogIndex(long handle, String path) {
        return Myotis_engineKt.exportLogIndex(handle, nz(path));
    }

    /** Verified {@code eth_feeHistory} (feeHistory JSON / error). */
    static String nativeFeeHistoryJson(
            long handle, long blockCount, String newestBlockTag, String percentilesJson) {
        return Myotis_engineKt.feeHistoryJson(
                handle, blockCount, nz(newestBlockTag), nz(percentilesJson));
    }
}
