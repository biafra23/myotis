package io.myotis.engines.rust;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;
import io.myotis.api.AccountProofResult;
import io.myotis.api.BeaconState;
import io.myotis.api.BeaconStatus;
import io.myotis.api.BlockResult;
import io.myotis.api.ChainHandle;
import io.myotis.api.ClPeerInfo;
import io.myotis.api.ConnectedPeer;
import io.myotis.api.DataUsage;
import io.myotis.api.DialResult;
import io.myotis.api.DiscoveredPeer;
import io.myotis.api.EngineException;
import io.myotis.api.EnsApi;
import io.myotis.api.EnsResolutionResult;
import io.myotis.api.HeadersResult;
import io.myotis.api.LifecycleState;
import io.myotis.api.NetworkMetering;
import io.myotis.api.NodeStatusReads;
import io.myotis.api.PeerInfo;
import io.myotis.api.StatusSnapshot;
import io.myotis.api.StorageProofResult;
import io.myotis.api.UpgradeAdvisory;
import io.myotis.api.UpgradePhase;
import io.myotis.api.VerifiedReads;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * The Rust engine's {@link ChainHandle}: one hosted network — mainnet, Sepolia or
 * Gnosis, whichever {@link RustMyotisEngine#create} was asked for — backed by a
 * {@code myotis_net::SyncHandle} (the light-client sync loop) and the Rust
 * {@code ElReader} (discv4 + peer pool + the CL-fed execution anchor), running on the
 * tokio runtime the native engine owns. Lifecycle + status cross the FFI boundary via
 * {@link RustEngineNative} (the UniFFI bindings); compound status is a JSON object
 * (the FFI + JSON decision, pinned by golden tests on both sides).
 *
 * <p>The status snapshot is real on both sides: the beacon fields (finalized slot,
 * sync period, peer count, beacon state) and the EL fields (snap-peer and
 * snap-serving counts, discovered / backed-off / blacklisted peers, attempted dials)
 * are parsed from the native status JSON, and the verified-head age is tracked here
 * from the optimistic head's advance. The verified-read queries —
 * {@link #requestAccount}/{@link #getStorageProof} and the whole {@link VerifiedReads}
 * surface behind {@link #reads()} — cross to the Rust {@code ElReader} and return the
 * same proof/verdict records as the Java engine. The three operator queries
 * ({@link #getHeaders}/{@link #getBlockVerified}/{@link #dialPeer}) throw
 * {@link EngineException} by design ({@code NOT_AVAILABLE} below): block reads go
 * through {@link VerifiedReads}, and the engine dials from its own pool.
 *
 * <p>{@link #reads()} is the verified read surface ({@link RustVerifiedReads}, answered
 * in-process from the native engine). A host that wants it on the wire attaches a
 * {@link LoopbackRpc} listener: on {@link #start()} this handle starts it on
 * {@code 127.0.0.1:rpcPort}, mirroring how the Java engine self-starts the shared
 * {@code jsonrpc-server} inside {@code ChainStack}. The JVM hosts get that listener
 * from the selector; the engine library attaches none.
 *
 * <p>Idle sleep is REAL on this engine (the Java engine's behaviour, mirrored for
 * Android): {@link #pause()} tears the native networking down while the handle and
 * the JSON-RPC listener stay, {@link #resume(String)} warm-starts from the
 * persisted snapshot/peer caches, and every verified read below crosses the same
 * {@code WakeGate} the Java engine uses — a request on a paused stack wakes it and
 * is held (bounded, ~90 s) until the node can answer.
 */
final class RustChainHandle implements ChainHandle, NodeStatusReads, io.myotis.api.NodeLifecycle {

    private static final Logger log = LoggerFactory.getLogger(RustChainHandle.class);

    /** Message for the operator queries only the Java engine serves — {@code get-headers},
     *  {@code get-block} and {@code dial}. The Rust engine's block reads go through
     *  {@link io.myotis.api.VerifiedReads} instead, and it dials from its own pool. */
    private static final String NOT_AVAILABLE =
            "not available on the Rust engine (a Java-engine operator query: get-headers, get-block, dial)";

    private final long handle;
    private final String networkName;
    private final long chainId;
    /** Loopback JSON-RPC port; {@code <= 0} disables the listener (e.g. the JSON test seams). */
    private final int rpcPort;
    /** The verified read surface; never null. Served on the wire by {@link #rpc} when set. */
    private final RustVerifiedReads verifiedReads = new RustVerifiedReads(this);
    /** The host's loopback listener (a port — see {@link LoopbackRpc}), or null when the
     *  host attaches none (the engine library). It owns the web-page gate (#502), so the
     *  policy works before the listener is up and after it stopped (ChainStack parity). */
    private final LoopbackRpc rpc;
    /** Whether {@link #rpc} was started by this run's start(); cleared in stop(). */
    private volatile boolean rpcStarted;

    /** Monotonic time (ns) the current run's start() was ENTERED — uptime counts the native
     *  boot itself, not just the time since it finished; drives {@link #uptimeSeconds()}.
     *  Paired with {@link #started} because nanoTime()'s origin is arbitrary (0 is a valid
     *  reading). */
    private volatile long startedAtNs;
    private volatile boolean started;

    /** Head-freshness tracking for verifiedHeadAgeMs: the last optimistic-head block
     *  number seen, and the monotonic time it was first seen. The reported age is the
     *  elapsed time since the head last ADVANCED — a real age (0 → ~12 s per block,
     *  growing if the head stalls), not a constant. Guarded by {@link #headAgeLock}
     *  so the paired check-and-update is atomic across concurrent status() callers
     *  (UI poll + health thread) — a torn read would yield a spurious huge age.
     *  A DEDICATED lock (not {@code this}) so it never contends with start()/stop(). */
    private final Object headAgeLock = new Object();
    private long lastHeadBlock = -1L;
    private long lastHeadAdvanceNanos;

    /** CCIP-Read HTTP transport from EnginePorts; null = offchain names error. */
    private final io.myotis.api.ports.HttpGateway httpGateway;

    RustChainHandle(long handle, String networkName, long chainId, int rpcPort, boolean hasEns) {
        this(handle, networkName, chainId, rpcPort, hasEns, null);
    }

    RustChainHandle(long handle, String networkName, long chainId, int rpcPort, boolean hasEns,
            io.myotis.api.ports.HttpGateway httpGateway) {
        this(handle, networkName, chainId, rpcPort, hasEns, httpGateway, null);
    }

    RustChainHandle(long handle, String networkName, long chainId, int rpcPort, boolean hasEns,
            io.myotis.api.ports.HttpGateway httpGateway, LoopbackRpc rpc) {
        this.handle = handle;
        this.networkName = networkName;
        this.chainId = chainId;
        this.rpcPort = rpcPort;
        this.httpGateway = httpGateway;
        this.rpc = rpc;
        // Networks without a name service get no EnsApi — ens() returns null. (gnosis
        // has one: Genome's .gno names, resolved by the same native walk.)
        this.ensApi = hasEns ? new RustEnsApi(this) : null;
        // Wake-on-request over the NATIVE lifecycle: the same primitive ChainStack
        // wires, so the two engines share the hold/single-flight semantics.
        this.wakeGate = new io.myotis.engines.common.WakeGate(this::lifecycle, this::readyForReads,
                this::notReadyDetail, () -> resume(io.myotis.api.WakeReason.REQUEST),
                System::currentTimeMillis, WAKE_POLL_MS, networkName);
    }

    io.myotis.api.ports.HttpGateway httpGateway() {
        return httpGateway;
    }

    @Override public String networkName() { return networkName; }

    @Override public long chainId() { return chainId; }

    @Override
    public synchronized boolean start() {
        // Entry stamp for uptime: count from the start request, including the native
        // boot itself — anchored below only when the start succeeds.
        long startRequestNs = System.nanoTime();
        // Warm-up window BEFORE the native flip (WakeGate#beginWarmup), as resume() does:
        // reads that arrive while the fresh stack climbs to SYNCED + snap peers are held
        // (bounded), and one racing this start on another thread (a UI / IPC operator query;
        // the listener itself only starts below) never sees RUNNING without a window. Only
        // from STOPPED, the one state a start can succeed from, so a refused start() can't
        // reopen a window over a serving node; a window a failed start leaves behind closes
        // at the watcher's first poll (still STOPPED).
        if (lifecycle() == LifecycleState.STOPPED) wakeGate.beginWarmup(WAKE_WAIT_CAP_MS);
        boolean ok = RustEngineNative.nativeStart(handle);
        // Only expose the verified JSON-RPC endpoint once the native stack is up.
        if (ok) {
            // Anchor uptime to this successful start (cleared in stop() so a restart re-anchors).
            if (!started) { startedAtNs = startRequestNs; started = true; }
            startRpc();
        }
        return ok;
    }

    @Override
    public synchronized void stop() {
        // Stop serving before tearing down the native stack the reads depend on.
        if (rpcStarted) {
            try { rpc.stop(); } catch (Throwable ignored) {}
            rpcStarted = false;
        }
        started = false;   // a fresh start() after stop re-anchors uptime to that run
        RustEngineNative.nativeStop(handle);
    }

    // ---- idle-sleep lifecycle (mirrors ChainStack.pause/resume) ----
    //
    // pause() tears the native networking down (zero sockets, zero timers — the
    // radio can sleep) while the handle, its persisted warm state, and the
    // JSON-RPC LISTENER stay: a verified read arriving while paused goes through
    // the wake gate below, which triggers a single-flight resume(REQUEST) and
    // holds the request (bounded) until the node can answer. resume() re-runs
    // the native start path, which warm-starts from the persisted snapshot /
    // peer caches (no checkpoint re-bootstrap, no cold discovery). The
    // pause/resume accounting reuses the Java engine's SleepMetrics — including
    // the FOREGROUND observer-effect rule — so the two engines' status screens
    // can't drift.

    /** Max time a verified read arriving on a paused stack is held while the wake
     *  completes — and the warm-up window every (re)start opens, the only other time
     *  a read is held (mirrors ChainStack.WAKE_WAIT_CAP_MS). */
    static final long WAKE_WAIT_CAP_MS = 90_000L;
    /** Wake-wait poll interval (mirrors ChainStack.WAKE_POLL_MS). */
    private static final long WAKE_POLL_MS = 250L;

    /** Wake-on-request: activity stamping + single-flight resume + bounded request
     *  hold — the same primitive ChainStack wires (assigned in the constructor). */
    private final io.myotis.engines.common.WakeGate wakeGate;
    /** Idle-sleep bookkeeping (pause count / total paused / last wake) for the
     *  status screens. Mutated only under this handle's lifecycle monitor
     *  (pause/resume are synchronized), like ChainStack. */
    private final io.myotis.engines.common.SleepMetrics sleepMetrics = new io.myotis.engines.common.SleepMetrics();
    /** Requests currently being served; while non-zero lastActivityEpochMillis
     *  reports "now" so the host idle timer never pauses the stack mid-query. */
    private final java.util.concurrent.atomic.AtomicInteger inFlight =
            new java.util.concurrent.atomic.AtomicInteger();

    @Override
    public synchronized boolean pause() {
        if (RustEngineNative.nativePause(handle)) {
            sleepMetrics.onPause(System.currentTimeMillis(), System.nanoTime());
            if (rpc != null) rpc.onPause();   // its filters go with the pause (#714)
            log.info("[{}] paused (networking torn down; RPC keeps listening)", networkName);
            return true;
        }
        // No transition — idempotent success only when already PAUSED (a
        // created/stopped handle reports false, per the ChainHandle contract).
        return lifecycle() == LifecycleState.PAUSED;
    }

    @Override
    public boolean resume() {
        return resume(io.myotis.api.WakeReason.MANUAL);
    }

    @Override
    public synchronized boolean resume(String reason) {
        if (isRunning()) return true; // no-op success, no accounting (mirrors ChainStack)
        // Open the warm-up window BEFORE the native flip (WakeGate#beginWarmup): the reads
        // held through the pause keep holding while the light client re-anchors and the pool
        // re-dials, instead of being released the instant the native entry reads Running. A
        // failed resume stays PAUSED, where the gate holds regardless of the window.
        wakeGate.beginWarmup(WAKE_WAIT_CAP_MS);
        if (RustEngineNative.nativeResume(handle)) {
            // Foreground (observation) wakes count toward the total but must not
            // overwrite the last-wake reason — see WakeReason / SleepMetrics.
            sleepMetrics.onResume(System.currentTimeMillis(), System.nanoTime(), reason,
                    !io.myotis.api.WakeReason.FOREGROUND.equals(reason));
            // The listener normally survived the pause; if the FIRST start's bind
            // failed this retries it best-effort (mirrors ChainStack.resume).
            startRpc();
            log.info("[{}] resumed ({})", networkName, reason);
            return true;
        }
        // Not paused (stopped), or the rebuild failed and the native side stayed
        // PAUSED (retryable) — either way, not RUNNING now.
        log.warn("[{}] resume ({}) did not start the stack (stayed {})",
                networkName, reason, lifecycle());
        return false;
    }

    @Override
    public LifecycleState lifecycle() {
        ParsedStatus s = readStatus();
        if (s.running()) return LifecycleState.RUNNING;
        return s.paused() ? LifecycleState.PAUSED : LifecycleState.STOPPED;
    }

    // ---- io.myotis.api.NodeLifecycle (the myotis_pause / myotis_wakeup RPC seam) ----
    // pause() above already satisfies NodeLifecycle.pause(). wakeUp() is the RPC/IPC
    // wake — resume tagged WakeReason.IPC, matching the daemon's `resume` command.
    @Override public boolean wakeUp() { return resume(io.myotis.api.WakeReason.IPC); }
    @Override public String lifecycleName() { return lifecycle().name(); }

    @Override
    public long lastActivityEpochMillis() {
        // Epoch millis of the last gated verified read / operator query; 0 if none.
        // While a request is in flight this reports "now" so the host idle timer
        // holds off (mirrors ChainStack.lastActivityMs).
        return inFlight.get() > 0 ? System.currentTimeMillis() : wakeGate.lastActivityMs();
    }

    /**
     * Wake-and-wait shared by every verified read / operator query below: a query
     * on a paused stack triggers the (single-flight) resume and waits up to the cap
     * for readiness, as does one arriving during a start/resume warm-up. A RUNNING
     * stack that isn't ready proceeds — at once outside a warm-up (#312), at the
     * deadline inside one — and the native query produces its own precise bounded
     * errors. Only PAUSED-at-deadline (resume kept failing) throws; a STOPPED stack
     * falls through to the native's "handle not started"/"unknown handle" error
     * (mirrors JavaChainHandle.awaitWake).
     */
    private void awaitWake() {
        // Fast-fail the unrecoverable-while-RUNNING state (the twin of
        // ChainStack.awaitReadyForReads' "RUNNING with no backend" fast-fail):
        // RUNNING with no EL reader means the reader failed at start (the CL-only
        // degraded mode). No amount of waiting produces one without a pause→resume,
        // so let the native's precise "EL reader unavailable" error surface
        // immediately instead of holding every query the full ~90 s cap.
        ParsedStatus probe = readStatus();
        if (probe.running() && !probe.elReaderAvailable()) return;
        wakeGate.await(WAKE_WAIT_CAP_MS);
        if (lifecycle() == LifecycleState.PAUSED) {
            throw new EngineException("node did not become ready within "
                    + (WAKE_WAIT_CAP_MS / 1000) + "s (paused; resume failing)");
        }
    }

    /** Adapter seam ({@link RustVerifiedReads#headBlockNumber}): wake-and-hold;
     *  false when no verified answer is possible right now. */
    boolean awaitReadyForReads() {
        try {
            awaitWake();
            return true;
        } catch (EngineException e) {
            return false;
        }
    }

    /** Adapter seam: note activity and kick a wake if paused, without blocking
     *  (status probes — {@link RustVerifiedReads#syncState}). */
    void noteActivityAndWake() {
        wakeGate.poke();
    }

    /**
     * The wake-on-request choke point every verified read crosses before its JNI
     * call (the Rust-engine twin of ChainStack.awaitReadyForReads + the
     * begin/endRequest in-flight guard): stamps activity, wakes a paused stack,
     * holds (bounded) while the stack is waking — paused, or in a start/resume
     * warm-up — and marks the request in flight so the host idle timer can't pause
     * the stack mid-query.
     */
    private <T> T gated(java.util.function.Supplier<T> nativeCall) {
        awaitWake();
        inFlight.incrementAndGet();
        try {
            return nativeCall.get();
        } finally {
            inFlight.decrementAndGet();
        }
    }

    /** Readiness for verified reads — {@link #serveable(ParsedStatus)} plus the
     *  states no amount of holding fixes (the Rust twin of
     *  ChainStack.readyForReads). */
    private boolean readyForReads() {
        try {
            return readyForReads(readStatus());
        } catch (RuntimeException e) {
            return false; // an unreadable status is "not ready", never a wake-loop crash
        }
    }

    /** {@link #readyForReads()} over one parsed status — pure, so it is testable
     *  without JNI ({@link #readyForReadsFromJson}). */
    private static boolean readyForReads(ParsedStatus s) {
        // RUNNING with no EL reader is terminal-until-pause/resume (the CL-only
        // degraded mode): more waiting cannot help, so report "attempt the read
        // now" and let the native surface its precise "EL reader unavailable"
        // error. The pre-gate probe in awaitWake covers the already-RUNNING
        // case without stamping activity; this covers a wake whose resume
        // lands in the degraded mode MID-HOLD, which would otherwise park the
        // request for the rest of the warm-up.
        if (s.running() && !s.elReaderAvailable()) return true;
        // A STALE_ANCHOR park is the same kind of state: only a human moves it (raise
        // the bound or accept the risk), so attempt now — the refusal comes back at
        // once as the router's curated STALE_ANCHOR message (ChainStack's rule too).
        if (s.running() && s.beaconState() == BeaconState.STALE_ANCHOR) return true;
        return s.running() && serveable(s);
    }

    /** A verified read can be served NOW: SYNCED, an anchored optimistic head, and
     *  a pooled snap peer that can answer at that head — {@code snapServingPeers},
     *  not the pooled count: right after SYNCED a pool of peers still syncing
     *  themselves keeps {@code snapPeers} positive for hours while every read
     *  fails (#465). The one predicate {@link #readyForReads} holds on and
     *  {@link #status(ParsedStatus)} ages the verified head by. */
    private static boolean serveable(ParsedStatus s) {
        return s.beaconState() == BeaconState.SYNCED
                && s.optimisticBlockNumber() > 0 && s.snapServingPeers() > 0;
    }

    /** Package-private test seam: the readiness predicate over a status JSON, without JNI. */
    static boolean readyForReadsFromJson(String json) {
        return readyForReads(ParsedStatus.parse(json));
    }

    /** Why reads aren't answerable yet, for the wake gate's slow-hold WARN. */
    private String notReadyDetail() {
        ParsedStatus s = readStatus();
        // Both counts: "6 pooled, 0 serving" is the diagnosis of a pool of
        // peers that are still syncing themselves (#465).
        return "beacon " + s.beaconState() + ", snapPeers " + s.snapPeers()
                + " (" + s.snapServingPeers() + " serving), head " + s.optimisticBlockNumber();
    }

    /** {@link NodeStatusReads}: node uptime for the JSON-RPC myotis_status result. Monotonic
     *  (nanoTime), so it's immune to wall-clock/NTP adjustments; 0 before the first start. */
    @Override
    public long uptimeSeconds() {
        return !started ? 0L : (System.nanoTime() - startedAtNs) / 1_000_000_000L;
    }

    /** Live listener state (bound AND no fatal supervisor failure) — ChainStack parity. */
    private boolean rpcServing() {
        return rpcStarted && rpc.isServing();
    }

    /**
     * Start the host's {@link LoopbackRpc} listener on {@code 127.0.0.1:rpcPort}, backed
     * by {@link RustVerifiedReads} — the Rust-engine counterpart to
     * {@code ChainStack.startRpc()}. A bind failure is logged and the stack continues
     * without JSON-RPC (mirrors the Java engine): the IPC socket still serves the same
     * verified primitives. No listener attached (the engine library) = nothing to start.
     */
    private void startRpc() {
        if (rpc == null) return;         // no listener attached (in-process consumer)
        if (rpcPort <= 0) return;        // RPC disabled (test seam / explicit opt-out)
        if (rpcStarted) return;          // already started — avoid a re-bind / server leak
        try {
            rpc.start(rpcPort, verifiedReads, this, this);
            rpcStarted = true;
            log.info("[{}] JSON-RPC listening on http://127.0.0.1:{} (verified, strict)",
                    networkName, rpcPort);
        } catch (java.io.IOException bindEx) {
            log.warn("[{}][rpc] port {} unavailable ({}); continuing without JSON-RPC",
                    networkName, rpcPort, bindEx.getMessage());
        } catch (Throwable t) {
            log.warn("[{}][rpc] failed to start JSON-RPC; continuing without it: {}",
                    networkName, t.toString());
        }
    }

    @Override public boolean isRunning() { return readStatus().running(); }

    // ---- status ----

    /** Parse the native status JSON; a null/empty payload → an unknown/dead handle. */
    private ParsedStatus readStatus() {
        String json = RustEngineNative.nativeStatusJson(handle);
        return ParsedStatus.parse(json);
    }

    /** The parsed native status object — CL fields plus the EL pool/discovery
     *  counts. Older natives omit the EL keys → they default to 0 (and the
     *  paused key → false, so an older .so can only ever look RUNNING/STOPPED). */
    private record ParsedStatus(
            boolean running,
            boolean paused,
            boolean elReaderAvailable,
            BeaconState beaconState,
            boolean bootstrapped,
            long finalizedSlot,
            long optimisticSlot,
            long currentPeriod,
            long targetPeriod,
            long peerCount,
            int servedPeersLastMinute,
            int discv5TableSize,
            long syncStartPeriod,
            int snapPeers,
            int snapServingPeers,
            int snap2ServingPeers,
            int discoveredPeers,
            int attemptedDials,
            int backedOffPeers,
            int blacklistedPeers,
            long optimisticBlockNumber,
            long finalizedBlockNumber,
            long peerHeaderRequests,
            long peerHeaderRequestsServed,
            long peerBodyRequests,
            long peerBodyRequestsServed,
            boolean lcHunting,
            boolean elHunting,
            long wsBoundPeriods,
            UpgradeAdvisory upgradeAdvisory,
            DataUsage dataUsage,
            NetworkMetering networkMetering) {

        /** {@code beaconState} tolerant of a NEWER .so than this wrapper: an
         *  unrecognized value maps to STARTING (not-ready, fail closed) instead of
         *  the whole status parse throwing — the same skew hygiene as the missing
         *  targetPeriod fallback. */
        private static BeaconState beaconStateOf(String name) {
            try {
                return BeaconState.valueOf(name);
            } catch (IllegalArgumentException e) {
                return BeaconState.STARTING;
            }
        }

        static ParsedStatus parse(String json) {
            if (json == null || json.isBlank()) return notRunning();
            try {
                JsonObject o = Json.parse(json).asObject();
                if (o.isEmpty()) return notRunning(); // "{}" == unknown handle
                return new ParsedStatus(
                        o.getBoolean("running", false),
                        o.getBoolean("paused", false),
                        o.getBoolean("elReaderAvailable", false),
                        beaconStateOf(o.getString("beaconState", "STARTING")),
                        o.getBoolean("bootstrapped", false),
                        o.getLong("finalizedSlot", 0L),
                        o.getLong("optimisticSlot", 0L),
                        o.getLong("currentPeriod", 0L),
                        o.getLong("targetPeriod", 0L),
                        o.getLong("peerCount", 0L),
                        o.getInt("servedPeersLastMinute", 0),
                        o.getInt("discv5TableSize", 0),
                        o.getLong("syncStartPeriod", -1L),
                        o.getInt("snapPeers", 0),
                        // ABI >= 31: the pooled peers that can answer at the anchored
                        // head (#465). Absent → 0 like every other EL key — fail
                        // CLOSED, never the pooled count: the ABI gate is exact, so a
                        // native this wrapper loads always emits it.
                        o.getInt("snapServingPeers", 0),
                        // ABI >= 38: the part of snapServingPeers on snap/2 (EIP-8189).
                        // Shown, never gated on.
                        o.getInt("snap2ServingPeers", 0),
                        o.getInt("discoveredPeers", 0),
                        o.getInt("attemptedDials", 0),
                        o.getInt("backedOffPeers", 0),
                        o.getInt("blacklistedPeers", 0),
                        o.getLong("optimisticBlockNumber", 0L),
                        o.getLong("finalizedBlockNumber", 0L),
                        o.getLong("peerHeaderRequests", 0L),
                        o.getLong("peerHeaderRequestsServed", 0L),
                        o.getLong("peerBodyRequests", 0L),
                        o.getLong("peerBodyRequestsServed", 0L),
                        o.getBoolean("lcHunting", false),
                        o.getBoolean("elHunting", false),
                        // Older .so vintages don't emit it; 0 = "bound unknown".
                        o.getLong("wsBoundPeriods", 0L),
                        parseAdvisory(o.get("upgradeAdvisory")),
                        // ABI >= 50 (docs/data-usage.md). Display-only, like the
                        // advisory: absent or malformed → NONE / UNKNOWN, never
                        // a "malformed status" failure.
                        parseDataUsage(o.get("dataUsage")),
                        meteringOf(o.get("networkMetering")));
            } catch (RuntimeException e) {
                throw new EngineException(
                        "malformed status JSON from the Rust engine: " + e.getMessage(), e);
            }
        }

        static ParsedStatus notRunning() {
            return new ParsedStatus(false, false, false, BeaconState.STARTING, false, 0L, 0L, 0L,
                    0L, 0L, 0, 0, -1L, 0, 0, 0, 0, 0, 0, 0, 0L, 0L, 0L, 0L, 0L, 0L, false, false, 0L, null,
                    DataUsage.NONE, NetworkMetering.UNKNOWN);
        }

        /** The nested {@code dataUsage} object → the API record; absent, null or
         *  not an object → {@link DataUsage#NONE}. */
        static DataUsage parseDataUsage(JsonValue v) {
            if (v == null || !v.isObject()) return DataUsage.NONE;
            JsonObject u = v.asObject();
            try {
                return new DataUsage(
                        u.getLong("bytesIn", 0L), u.getLong("bytesOut", 0L),
                        u.getLong("elBytesIn", 0L), u.getLong("elBytesOut", 0L),
                        u.getLong("clBytesIn", 0L), u.getLong("clBytesOut", 0L),
                        u.getString("day", ""),
                        u.getLong("todayBytesIn", 0L), u.getLong("todayBytesOut", 0L),
                        u.getLong("todayMeteredBytesIn", 0L), u.getLong("todayMeteredBytesOut", 0L));
            } catch (RuntimeException wrongType) {
                return DataUsage.NONE;
            }
        }

        /** {@code networkMetering}: absent, not a string, or a name this wrapper
         *  doesn't know → UNKNOWN. */
        static NetworkMetering meteringOf(JsonValue v) {
            if (v == null || !v.isString()) return NetworkMetering.UNKNOWN;
            try {
                return NetworkMetering.valueOf(v.asString());
            } catch (IllegalArgumentException e) {
                return NetworkMetering.UNKNOWN;
            }
        }

        /** The optional nested {@code upgradeAdvisory} object → the API record. Absent
         *  (older natives), JSON null, a non-object, or a phase this wrapper doesn't know
         *  (a newer native) → null: an advisory is display-only and must never turn a
         *  status read into a "malformed status" failure. */
        static UpgradeAdvisory parseAdvisory(JsonValue v) {
            if (v == null || !v.isObject()) return null;
            JsonObject a = v.asObject();
            try {
                return new UpgradeAdvisory(UpgradePhase.valueOf(a.getString("phase", "")),
                        a.getLong("activationTime", 0L), a.getString("forkId", ""),
                        a.getInt("observedPeers", 0));
            } catch (RuntimeException unknownPhaseOrWrongType) {
                return null;
            }
        }
    }

    @Override
    public StatusSnapshot status() {
        return status(readStatus());
    }

    /**
     * Map a native status JSON payload to a {@link StatusSnapshot} for {@code network}.
     * Package-private test seam: exercises the JSON→snapshot mapping without JNI.
     */
    static StatusSnapshot statusFromJson(String network, String json) {
        return new RustChainHandle(0L, network, 1L, 0, false).status(ParsedStatus.parse(json));
    }

    /** Package-private test seam: JSON→{@link BeaconStatus} without JNI. */
    static BeaconStatus beaconStatusFromJson(String network, String json) {
        return new RustChainHandle(0L, network, 1L, 0, false).beaconStatus(ParsedStatus.parse(json));
    }

    /** Package-private test seam: map a status JSON on THIS handle (so head-age
     *  tracking persists across calls). Lets a test observe verifiedHeadAgeMs grow. */
    StatusSnapshot statusFromJsonOnThisHandle(String json) {
        return status(ParsedStatus.parse(json));
    }

    private StatusSnapshot status(ParsedStatus s) {
        int peers = (int) Math.min(s.peerCount(), Integer.MAX_VALUE);
        // Older natives don't emit "targetPeriod" (parsed as 0): fall back to
        // currentPeriod — the pre-targetPeriod mirror — so the target >= current
        // invariant holds against any .so vintage.
        long targetPeriod = Math.max(s.targetPeriod(), s.currentPeriod());
        // EL pool/discovery counts now come from the Rust status JSON. The pool
        // keeps only snap-capable READY peers, so readyPeers == snapPeers;
        // snapServingPeers is the engine's own count of the pooled peers that can
        // answer at the anchored head now (ABI >= 31). Execution block numbers
        // (optimistic head + finalized) come from the beacon anchor via the status.
        //
        // verifiedHeadAgeMs drives the host's readiness dot (< 45 s = ready/green).
        // The Rust reader anchors every query to the peer's fresh head; there's no
        // separate head context to age, so age it by how long since the optimistic
        // head last ADVANCED (a new block ~every 12 s resets it) — a REAL, changing
        // age, not a constant. Reported only when a verified read CAN be served
        // (SYNCED, an anchored head, snap peers); else the Long.MAX_VALUE "no
        // verified head yet" sentinel — and while NOT serveable we hold the advance
        // clock at "now" so the age starts fresh the instant we become serveable
        // (a not-serving stretch must not leak in as a stale age → amber flicker).
        // Monotonic nanoTime — a wall-clock/NTP jump must not distort the age.
        long optHead = s.optimisticBlockNumber();
        long nowNanos = System.nanoTime();
        boolean serveable = serveable(s);
        long verifiedHeadAgeMs;
        synchronized (headAgeLock) {
            if (!serveable) {
                // No verified head to age; keep the clock pinned to now so the first
                // serveable poll starts near 0 rather than carrying the outage gap.
                lastHeadBlock = optHead;
                lastHeadAdvanceNanos = nowNanos;
                verifiedHeadAgeMs = Long.MAX_VALUE;
            } else {
                if (optHead != lastHeadBlock) {
                    lastHeadBlock = optHead;
                    lastHeadAdvanceNanos = nowNanos;
                }
                verifiedHeadAgeMs = Math.max(0L, (nowNanos - lastHeadAdvanceNanos) / 1_000_000L);
            }
        }
        return new StatusSnapshot(
                s.running(),
                s.running() ? LifecycleState.RUNNING
                        : s.paused() ? LifecycleState.PAUSED : LifecycleState.STOPPED,
                networkName,
                s.beaconState(),
                peers,                 // connectedPeers (CL libp2p peers)
                s.snapPeers(),         // readyPeers (EL — pool holds only snap-ready)
                s.snapPeers(),         // snapPeers
                s.snapServingPeers(),  // snapServingPeers (ABI >= 31)
                s.snap2ServingPeers(), // snap2ServingPeers (ABI >= 38)
                s.discoveredPeers(),   // discoveredPeers (discv4)
                s.backedOffPeers(),    // backedOffPeers
                s.blacklistedPeers(),  // blacklistedPeers
                s.attemptedDials(),    // attemptedDials
                s.discv5TableSize(),
                s.finalizedBlockNumber(),   // executionBlockNumber (== finalized payload's block)
                s.optimisticBlockNumber(),  // optimisticBlockNumber (the eth_blockNumber head)
                s.finalizedSlot(),
                s.finalizedBlockNumber(),   // finalizedBlockNumber
                s.syncStartPeriod(),
                s.currentPeriod(),
                targetPeriod,
                s.finalizedSlot() / 8192L, // finalizedPeriod (SLOTS_PER_SYNC_COMMITTEE_PERIOD)
                targetPeriod,   // wallClockPeriod == the catch-up target
                verifiedHeadAgeMs,
                s.wsBoundPeriods(),
                List.<PeerInfo>of(),
                // Idle-sleep metrics, accounted Java-side across the native
                // pause/resume transitions (same SleepMetrics as the Java engine).
                sleepMetrics.pauseCount(),
                sleepMetrics.totalPausedMs(),
                sleepMetrics.lastPauseEpochMs(),
                sleepMetrics.lastResumeEpochMs(),
                sleepMetrics.lastWakeReason(),
                // Inbound-serve counters, parsed from the Rust engine's status JSON.
                s.peerHeaderRequests(),
                s.peerHeaderRequestsServed(),
                s.peerBodyRequests(),
                s.peerBodyRequestsServed(),
                s.lcHunting(),
                s.elHunting(),
                // Host-side listener truth (the JVM owns the server for Rust-hosted
                // networks): the configured port — while the handle runs OR is
                // idle-paused (the listener deliberately survives pause: a request
                // on 127.0.0.1:rpcPort is what WAKES the stack) — and whether the
                // server is live right now. Only a STOPPED handle reports 0, hiding
                // the row instead of faking a red bind failure.
                (s.running() || s.paused()) && rpc != null && rpcPort > 0 ? rpcPort : 0,
                rpcServing(),
                s.upgradeAdvisory(),
                s.dataUsage(),
                s.networkMetering());
    }

    @Override
    public BeaconStatus beaconStatus() {
        return beaconStatus(readStatus());
    }

    private BeaconStatus beaconStatus(ParsedStatus s) {
        int peers = (int) Math.min(s.peerCount(), Integer.MAX_VALUE);
        return new BeaconStatus(
                s.beaconState(),
                s.bootstrapped(),
                s.currentPeriod(),
                // Same older-.so fallback as status(): missing key parses as 0.
                Math.max(s.targetPeriod(), s.currentPeriod()),
                s.discv5TableSize(),
                peers,                 // connectedPeers (CL)
                s.peerCount(),         // lightClientPeers
                s.servedPeersLastMinute(),
                s.finalizedSlot(),
                s.optimisticSlot(),
                s.finalizedSlot() / 8192L,  // finalizedPeriod = period OF the finalized
                                            // slot (SLOTS_PER_SYNC_COMMITTEE_PERIOD),
                                            // consistent with StatusSnapshot — not the
                                            // committee's currentPeriod.
                null,                  // executionStateRootHex (not in the status JSON)
                null,                  // executionBlockHashHex (not in the status JSON)
                s.finalizedBlockNumber(),  // executionBlockNumber (== finalized payload's block)
                0,                     // knownStateRoots
                0,                     // fillThreshold
                s.wsBoundPeriods(),
                List.<ClPeerInfo>of());
    }

    // ---- verified-read surface ----
    //
    // reads() returns the RustVerifiedReads adapter — the read surface the host's
    // LoopbackRpc listener serves on 127.0.0.1:rpcPort (started in startRpc()). It
    // answers the whole VerifiedReads surface from the native engine: the
    // beacon-anchored account / storage / code reads from the same proof-verified
    // queries as requestAccount below, eth_call and estimateGas (state overrides
    // included), block, transaction, receipt and fee reads, eth_getLogs over the log
    // index, and sendRawTransaction. A null from one of its methods means "can't
    // answer verified" for THAT request (an unservable block pin, malformed input, no
    // proof at the anchor) — not an unimplemented method.
    //
    // Per the ChainHandle contract, reads() is null "while the RPC backend isn't
    // started (e.g. the RPC port was unavailable at start())". The adapter is itself
    // transport-independent (it queries the native directly), but with a listener
    // attached reads() gates on it so it means the same thing on both engines: the
    // Java engine's rpcBackend is null until startRpc() succeeds, and hosts null-check
    // reads() to decide whether verified RPC is available. So: null before start(),
    // when rpcPort<=0, or on a bind failure; non-null once serving. With NO listener
    // (the engine library's in-process consumer) there is no backend to wait for:
    // reads() is non-null once start() succeeded, null before.
    //
    // ens() serves every EnsApi record type via the native resolver, and is non-null
    // only on name-capable networks: mainnet and Sepolia have the ENS registry,
    // gnosis Genome's .gno registry; a network without one has hasEns false and
    // ens() null per the ChainHandle contract. Every failure — a resolver fault, an offchain name CCIP could not be
    // driven for, bad arguments, even not-running — lands in the record's error
    // field (RustEnsApi's documented divergence from JavaEnsApi, which throws for the
    // last two). The operator queries further down (getHeaders/getBlockVerified/
    // dialPeer) throw EngineException (NOT_AVAILABLE): the contract reserves
    // exceptions for malformed input / not running, and a surface this engine does
    // not serve is a capability error (no verification to report a failReason for)
    // — a failReason record would misrepresent "we don't" as "we tried and failed".

    @Override public VerifiedReads reads() {
        return (rpc == null ? started : rpcStarted) ? verifiedReads : null;
    }

    // Non-null only for name-capable networks (hasEns; the ChainHandle contract
    // returns null elsewhere). Assigned in the constructor since it depends on hasEns.
    private final EnsApi ensApi;

    @Override public EnsApi ens() { return ensApi; }

    @Override
    public List<DiscoveredPeer> discoveredPeers() { return List.of(); }

    @Override
    public List<ConnectedPeer> connectedPeers() { return List.of(); }

    @Override
    public void setTargetSnapPeers(int target) {
        // The Rust engine sizes its own snap pool (see myotis-net's PoolConfig) and
        // exports no target knob over the FFI, so the Settings value has nothing to
        // reach; the Java engine's maintainer is the only consumer of it.
        log.debug("[engines] setTargetSnapPeers({}) is a no-op on the Rust engine (it sizes its own pool)",
                target);
    }

    @Override
    public void setServedBlockWindow(int blocks) {
        // Applied live on a running EL handle; stashed engine-side and applied at
        // the next start for any other known state (hosts set the knob between
        // create() and start()). False only for an unknown handle — log it, since
        // a silently dropped Settings value is the bug this path used to have.
        if (!RustEngineNative.nativeSetServedBlockWindow(handle, blocks)) {
            log.warn("[engines] setServedBlockWindow({}) dropped: unknown handle {}", blocks, handle);
        }
    }

    @Override
    public void setWsBoundPeriods(long periods) {
        // Applied live through the engine's shared WsPolicy — a STALE_ANCHOR park
        // re-evaluates within a second. False only for an unknown handle; log it,
        // since a silently dropped Settings value is the bug this path used to have.
        if (!RustEngineNative.nativeSetWsBoundPeriods(handle, periods)) {
            log.warn("[engines] setWsBoundPeriods({}) dropped: unknown handle {}", periods, handle);
        }
    }

    @Override
    public io.myotis.api.WebAccessPolicy setWebAccessPolicy(io.myotis.api.WebAccessPolicy policy) {
        // The listener is host-side on both engines, so the policy never crosses the
        // FFI: it lands on the gate the listener owns — live, and before start() too
        // (hosts set it between create() and start()). With no listener there is
        // nothing that could judge an origin, but the contract's answer is the same
        // pure function of the input: the mode with the origins normalized and the
        // entries that are no origin dropped, so a host's "was an entry dropped?"
        // compare works whether or not a listener exists (CLAUDE.md: applied or
        // refused, never silently ignored).
        if (rpc != null) return rpc.setWebAccessPolicy(policy);
        return new io.myotis.api.WebAccessPolicy(policy.mode(),
                io.myotis.jsonrpc.policy.WebOrigins.INSTANCE.normalizeEach(policy.origins()));
    }

    @Override
    public List<io.myotis.api.WebOrigin> recentWebOrigins() {
        return rpc == null ? List.of() : rpc.recentWebOrigins();
    }

    @Override
    public void acceptStaleAnchor() {
        if (!RustEngineNative.nativeAcceptStaleAnchor(handle)) {
            log.warn("[engines] acceptStaleAnchor dropped: unknown handle {}", handle);
        }
    }

    @Override
    public void clearPeerState() {
        // The Rust engine owns its peer caches as files under the data dir and exports
        // no clear over the FFI, so there is nothing to forward: the hosts' "Clear peer
        // caches" action deletes the files itself. That sticks only while the network
        // is stopped — a running pool rewrites the file from memory on its next flush.
        // The UI offers the action only while stopped anyway (a mis-click guard — owner
        // ruling, 2026-09-16; NodeScreen's maintenance block has the reasoning), which
        // on this engine is also the only window where the delete sticks; a live-handle
        // clear would need a new FFI export.
        log.debug("[engines] clearPeerState is a no-op on the Rust engine (the hosts delete its cache files)");
    }

    @Override
    public AccountProofResult requestAccount(String hexAddress) {
        return accountVerified(hexAddress, "");
    }

    /** Package-private test seam: JSON → {@link AccountProofResult} without JNI. */
    static AccountProofResult accountFromJson(String hexAddress, String json) {
        return accountFromJson(hexAddress, parseResultOrThrow(json, "account"));
    }

    private static AccountProofResult accountFromJson(String hexAddress, JsonObject o) {
        try {
        return new AccountProofResult(
                o.getString("address", hexAddress),
                o.getBoolean("exists", false),
                o.getLong("nonce", -1L),
                stringOrNull(o, "balanceWei"),
                stringOrNull(o, "storageRootHex"),
                stringOrNull(o, "codeHashHex"),
                o.getLong("blockNumber", 0L),
                stringOrNull(o, "peerStateRootHex"),
                o.getBoolean("peerProofValid", false),
                o.getBoolean("beaconChainVerified", false),
                o.getBoolean("blsVerified", false),
                o.getLong("matchedBeaconSlot", -1L),
                stringOrNull(o, "verifyMethod"),
                stringOrNull(o, "failReason"),
                stringOrNull(o, "accountHashHex"),
                stringList(o, "proofNodesHex"),
                o.getBoolean("beaconSynced", false),
                o.getLong("finalizedPeriod", 0L),
                o.getLong("wallClockPeriod", 0L),
                o.getLong("finalizedBlockNumber", 0L),
                o.getLong("optimisticBlockNumber", 0L),
                // ABI >= 41: the proven block timestamp, null when none is proven.
                longOrMinusOne(o, "blockTimestamp"),
                // ABI >= 52: the proven block hash, null when none is proven.
                stringOrNull(o, "blockHash"));
        } catch (RuntimeException e) {
            // A type-mismatched field (Rust-side shape drift) surfaces as an
            // EngineException, never a raw UnsupportedOperationException.
            throw new EngineException("malformed account JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    @Override
    public StorageProofResult getStorageProof(String hexAddress, long slot, String holderHexOrNull) {
        JsonObject o = parseResultOrThrow(
                gated(() -> RustEngineNative.nativeGetStorageProofJson(
                        handle, hexAddress, slot, holderHexOrNull)),
                "storage");
        return storageFromJson(hexAddress, slot, o);
    }

    /** Package-private test seam: JSON → {@link StorageProofResult} without JNI. */
    static StorageProofResult storageFromJson(String hexAddress, long slot, String json) {
        return storageFromJson(hexAddress, slot, parseResultOrThrow(json, "storage"));
    }

    // ---- VerifiedReads helpers (used by RustVerifiedReads; not ChainHandle API) ----

    /**
     * {@link #requestAccount(String)} at a block selector (ABI >= 32): a head tag or
     * empty reads the verified head, {@code finalized} the beacon-finalized block
     * (applied, never mapped to the head — #465, #366), a number only inside the
     * window around the head; anything else the engine refuses. Package-private:
     * the {@code io.myotis.api} surface has no block parameter yet, so only the
     * JSON-RPC adapter ({@link RustVerifiedReads}) reaches this.
     */
    AccountProofResult accountVerified(String hexAddress, String block) {
        JsonObject o = parseResultOrThrow(
                gated(() -> RustEngineNative.nativeRequestAccountJson(handle, hexAddress, block)),
                "account");
        return accountFromJson(hexAddress, o);
    }

    /**
     * Verified contract bytecode for {@code hexAddress} (eth_getCode) at the block
     * selector {@code block} (a head tag, {@code finalized}, or a near-head number —
     * the engine checks it, ABI >= 32), or null when
     * the query produced no verdict (can't answer verified). A verified EOA /
     * empty-code account yields an empty array. Throws {@link EngineException} on a
     * transport / not-running failure (the adapter maps that to null).
     */
    byte[] codeVerified(String hexAddress, String block) {
        return codeFromJson(gated(() -> RustEngineNative.nativeGetCodeJson(handle, hexAddress, block)));
    }

    /** Package-private test seam: code JSON → verified bytecode (or null) without JNI. */
    static byte[] codeFromJson(String json) {
        JsonObject o = parseResultOrThrow(json, "code");
        try {
            if (stringOrNull(o, "verifyMethod") == null) return null; // unverified → can't answer
            return hexToBytes(stringOrNull(o, "codeHex")); // 0x / empty → empty bytecode
        } catch (RuntimeException e) {
            throw new EngineException("malformed code JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /**
     * One verified {@code eth_call}: run it and return the result bytes, or null.
     * {@code from} is empty for an anonymous sender; {@code valueDecimal} is wei as
     * a decimal string. Throws {@link EngineException} on a transport / not-running
     * failure (the adapter maps that to null).
     */
    byte[] ethCallVerified(
            String fromHex, String toHex, String dataHex, String valueDecimal, String block) {
        return callResultFromJson(gated(() -> RustEngineNative.nativeEthCallJson(
                handle, fromHex, toHex, dataHex, valueDecimal, block)));
    }

    /**
     * {@link #ethCallVerified} with the {@code eth_call} state-override object as
     * JSON (empty ⇒ none) — the caller's hypothesis applied over verified state
     * for this call only.
     */
    byte[] ethCallVerifiedWithOverrides(
            String fromHex,
            String toHex,
            String dataHex,
            String valueDecimal,
            String block,
            String stateOverridesJson) {
        return callResultFromJson(gated(() -> RustEngineNative.nativeEthCallOverridesJson(
                handle, fromHex, toHex, dataHex, valueDecimal, block, stateOverridesJson)));
    }

    /** {@link #ethCallVerified} with the engine's three-way outcome — a revert
     *  carries its payload instead of collapsing to null. Same JNI native. */
    io.myotis.api.CallResult ethCallVerifiedDetailed(
            String fromHex, String toHex, String dataHex, String valueDecimal, String block) {
        return callDetailedFromJson(gated(() -> RustEngineNative.nativeEthCallJson(
                handle, fromHex, toHex, dataHex, valueDecimal, block)));
    }

    /** {@link #ethCallVerifiedDetailed} with the state-override object as JSON. */
    io.myotis.api.CallResult ethCallVerifiedDetailedWithOverrides(
            String fromHex,
            String toHex,
            String dataHex,
            String valueDecimal,
            String block,
            String stateOverridesJson) {
        return callDetailedFromJson(gated(() -> RustEngineNative.nativeEthCallOverridesJson(
                handle, fromHex, toHex, dataHex, valueDecimal, block, stateOverridesJson)));
    }

    /** Package-private test seam: call JSON → result bytes (or null) without JNI.
     *  The legacy two-state view of {@link #callDetailedFromJson}: only "ok"
     *  carries bytes; a revert, unavailable or refused outcome reads as null. */
    static byte[] callResultFromJson(String json) {
        io.myotis.api.CallResult r = callDetailedFromJson(json);
        return r.status() == io.myotis.api.CallResult.Status.OK ? r.data() : null;
    }

    /** Package-private test seam: call JSON → the engine's three-way outcome.
     *  The Rust side emits {@code {"status":"ok","resultHex"}} /
     *  {@code {"status":"revert","dataHex"}} / {@code {"status":"unavailable",
     *  "reason"}}, each with {@code blockNumber} (the block the call ran
     *  against) and {@code verified} (ran against the beacon-finalized block)
     *  since ABI 30 — all pinned by the eljson golden tests; an answered call
     *  ({@code ok}/{@code revert}) carries {@code blockNumber} on into
     *  {@link io.myotis.api.CallResult#blockNumber}, and {@code blockHash}
     *  (ABI 52, null unless proven) into {@code blockHashHex}; {@code verified} is not
     *  surfaced. A revert
     *  is a VERIFIED answer whose payload the host serves as the standard
     *  code-3 error. The permanent {@code {"error","code":-32602}} envelope (a
     *  block the node will never serve since ABI 27, an executor refusal since
     *  ABI 33) is {@link io.myotis.api.CallResult.Status#REFUSED}; a plain
     *  {@code {"error"}} still throws. {@code {"status":"infeasible","reason"}}
     *  (ABI 35: a transaction-object call, or a plain one whose calldata alone
     *  costs more than the budget — which only this engine charges) is
     *  {@link io.myotis.api.CallResult.Status#INFEASIBLE}: the call cannot
     *  succeed within the caller's gas, fee cap or funds, and {@code reason} is
     *  geth's message. */
    static io.myotis.api.CallResult callDetailedFromJson(String json) {
        JsonObject o = parseJsonObject(json, "call");
        String refusal = permanentRefusalOrNull(o);
        if (refusal != null) return io.myotis.api.CallResult.refused(refusal);
        throwIfError(o);
        try {
            String status = stringOrNull(o, "status");
            long block = o.getLong("blockNumber", -1L);
            String hash = stringOrNull(o, "blockHash"); // ABI >= 52; null when not proven
            if ("ok".equals(status)) {
                // 0x / empty → empty bytes
                return io.myotis.api.CallResult.ok(hexToBytes(stringOrNull(o, "resultHex"))).atBlock(block, hash);
            }
            if ("revert".equals(status)) {
                return io.myotis.api.CallResult.reverted(hexToBytes(stringOrNull(o, "dataHex"))).atBlock(block, hash);
            }
            if ("infeasible".equals(status)) {
                String reason = stringOrNull(o, "reason");
                if (reason == null || reason.isBlank()) {
                    throw new EngineException("call JSON: status=infeasible without a reason");
                }
                return io.myotis.api.CallResult.infeasible(reason);
            }
            return io.myotis.api.CallResult.unavailable(stringOrNull(o, "reason"));
        } catch (RuntimeException e) {
            throw new EngineException("malformed call JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /**
     * One verified ENS forward resolution: {@code name} → its
     * {@link EnsResolutionResult}. Throws {@link EngineException} on a transport /
     * not-running failure (the RustEnsApi adapter maps that to an error result).
     */
    EnsResolutionResult resolveEnsVerified(String name) {
        return ensResolutionFromJson(name,
                gated(() -> RustEngineNative.nativeResolveEnsJson(handle, name)));
    }

    /**
     * One generic ENS record query (EL-C-5-2): raw params JSON in, raw record
     * JSON out. Parsing/typing lives in {@link RustEnsApi} (its per-record
     * fromJson seams are the golden-tested halves); this is only the native
     * transport hop.
     */
    String ensRecordJson(String paramsJson) {
        return gated(() -> RustEngineNative.nativeEnsRecordJson(handle, paramsJson));
    }

    /** Package-private test seam: ENS JSON → {@link EnsResolutionResult} without JNI. */
    static EnsResolutionResult ensResolutionFromJson(String name, String json) {
        JsonObject o = parseResultOrThrow(json, "resolve-ens");
        try {
            String status = stringOrNull(o, "status");
            // blockNumber is part of the pinned native shape for ALL statuses; a
            // missing one is shape drift -> fail closed (like ok-without-address).
            var bn = o.get("blockNumber");
            if (bn == null || bn.isNull()) {
                throw new EngineException("resolve-ens JSON: missing blockNumber");
            }
            long block = bn.asLong();
            long blockTimestamp = longOrMinusOne(o, "blockTimestamp");
            // verified=false: the resolution IS proof-verified against the
            // beacon-anchored optimistic head, but "verified" in this API means a
            // beacon-FINALIZED root (see RustEnsApi) — don't overclaim.
            return switch (status == null ? "" : status) {
                // status=ok MUST carry an address; a missing one is native shape
                // drift -> fail closed (EngineException), NOT a silent result that
                // would read as the API's successful "no record" (same convention
                // as estimateGasFromJson's ok-without-gas).
                case "ok" -> {
                    String addressHex = stringOrNull(o, "addressHex");
                    if (addressHex == null || addressHex.isBlank()) {
                        throw new EngineException(
                                "resolve-ens JSON: status=ok without an addressHex");
                    }
                    yield new EnsResolutionResult(name, addressHex, block, false, null, blockTimestamp);
                }
                // API convention: addressHex==null && error==null is a SUCCESSFUL
                // "name has no record".
                case "noRecord" -> new EnsResolutionResult(name, null, block, false, null, blockTimestamp);
                case "offchain" -> new EnsResolutionResult(name, null, block, false,
                        "name resolves offchain (ERC-3668); CCIP-Read not yet supported"
                        + " on the rust engine", blockTimestamp);
                default -> throw new EngineException(
                        "resolve-ens JSON: unknown status '" + status + "'");
            };
        } catch (EngineException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new EngineException(
                    "malformed resolve-ens JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /**
     * One verified {@code eth_estimateGas} with the engine's three-way outcome —
     * a revert carries its payload instead of collapsing to null. {@code from}
     * empty for an anonymous sender; {@code valueDecimal} is wei as a decimal
     * string. Throws {@link EngineException} on a transport / not-running failure.
     */
    io.myotis.api.EstimateResult estimateGasVerifiedDetailed(
            String fromHex, String toHex, String dataHex, String valueDecimal) {
        return estimateGasDetailedFromJson(gated(() -> RustEngineNative.nativeEstimateGasJson(
                handle, fromHex, toHex, dataHex, valueDecimal)));
    }

    /**
     * One verified {@code eth_call} for the full transaction object (ABI 35,
     * #509): the arguments of {@link #estimateGasTxVerifiedDetailed}. Throws
     * {@link EngineException} on a transport / not-running failure.
     */
    io.myotis.api.CallResult callTxVerifiedDetailed(String txJson, String block, String stateOverridesJson) {
        return callDetailedFromJson(gated(() -> RustEngineNative.nativeEthCallTxJson(
                handle, txJson, block, stateOverridesJson)));
    }

    /**
     * One verified {@code eth_estimateGas} for the full transaction object (ABI 34,
     * #509): {@code txJson} is the canonical JSON the router built, {@code block}
     * the RPC block selector, {@code stateOverridesJson} a state override (empty ⇒
     * none). Throws {@link EngineException} on a transport / not-running failure.
     */
    io.myotis.api.EstimateResult estimateGasTxVerifiedDetailed(
            String txJson, String block, String stateOverridesJson) {
        return estimateGasDetailedFromJson(gated(() -> RustEngineNative.nativeEstimateGasTxJson(
                handle, txJson, block, stateOverridesJson)));
    }

    /**
     * One verified {@code eth_createAccessList} for the full transaction object
     * (ABI 40): the arguments of {@link #estimateGasTxVerifiedDetailed}. Throws
     * {@link EngineException} on a transport / not-running failure.
     */
    io.myotis.api.AccessListResult createAccessListVerified(String txJson, String block, String stateOverridesJson) {
        return accessListFromJson(gated(() -> RustEngineNative.nativeCreateAccessListJson(
                handle, txJson, block, stateOverridesJson)));
    }

    /**
     * One verified {@code debug_traceCall} (ABI 54, #716) for the full transaction
     * object, seen through the tracer {@code tracerJson} names. Throws
     * {@link EngineException} on a transport / not-running failure.
     */
    io.myotis.api.TraceResult traceCallVerified(String txJson, String block, String stateOverridesJson,
                                                String tracerJson) {
        return traceFromJson(gated(() -> RustEngineNative.nativeDebugTraceCallJson(
                handle, txJson, block, stateOverridesJson, tracerJson)));
    }

    /** Package-private test seam: trace JSON (ABI 54) → the engine's outcome:
     *  {@code {"status":"ok","trace":…}} / {@code {"status":"unavailable","reason"}} /
     *  {@code {"status":"infeasible","reason"}}; the permanent {@code {"error",
     *  "code":-32602}} is REFUSED and a plain {@code {"error"}} throws, as for
     *  {@link #accessListFromJson}. An {@code ok} without a trace is shape drift and
     *  fails closed. */
    static io.myotis.api.TraceResult traceFromJson(String json) {
        JsonObject o = parseJsonObject(json, "debug_traceCall");
        String refusal = permanentRefusalOrNull(o);
        if (refusal != null) return io.myotis.api.TraceResult.refused(refusal);
        throwIfError(o);
        String status = stringOrNull(o, "status");
        if ("ok".equals(status)) {
            var trace = o.get("trace");
            if (trace == null || !trace.isObject()) {
                throw new EngineException("debug_traceCall JSON: status=ok without a trace object");
            }
            return io.myotis.api.TraceResult.ok(trace.toString());
        }
        if ("infeasible".equals(status)) {
            String reason = stringOrNull(o, "reason");
            if (reason == null || reason.isBlank()) {
                throw new EngineException("debug_traceCall JSON: status=infeasible without a reason");
            }
            return io.myotis.api.TraceResult.infeasible(reason);
        }
        return io.myotis.api.TraceResult.unavailable(stringOrNull(o, "reason"));
    }

    /**
     * One verified {@code eth_simulateV1} (ABI 55, #716) of geth's {@code simOpts} object at
     * {@code block}. Throws {@link EngineException} on a transport / not-running failure.
     */
    io.myotis.api.SimulateResult simulateVerified(String optsJson, String block) {
        return simulateFromJson(gated(() -> RustEngineNative.nativeSimulateV1Json(handle, optsJson, block)));
    }

    /** Package-private test seam: simulate JSON (ABI 55) → the engine's outcome:
     *  {@code {"status":"ok","result":[…]}} / {@code {"status":"failed","code","message"}}
     *  (geth's own error) / {@code {"status":"unavailable","reason"}}; the permanent
     *  {@code {"error","code":-32602}} is REFUSED and a plain {@code {"error"}} throws, as
     *  for {@link #traceFromJson}. An {@code ok} without its result array, or a
     *  {@code failed} without its code or message, is shape drift and fails closed. */
    static io.myotis.api.SimulateResult simulateFromJson(String json) {
        JsonObject o = parseJsonObject(json, "eth_simulateV1");
        String refusal = permanentRefusalOrNull(o);
        if (refusal != null) return io.myotis.api.SimulateResult.refused(refusal);
        throwIfError(o);
        String status = stringOrNull(o, "status");
        if ("ok".equals(status)) {
            var result = o.get("result");
            if (result == null || !result.isArray()) {
                throw new EngineException("eth_simulateV1 JSON: status=ok without a result array");
            }
            return io.myotis.api.SimulateResult.ok(result.toString());
        }
        if ("failed".equals(status)) {
            var code = o.get("code");
            String message = stringOrNull(o, "message");
            if (code == null || !code.isNumber() || message == null || message.isBlank()) {
                throw new EngineException("eth_simulateV1 JSON: status=failed without a code and a message");
            }
            return io.myotis.api.SimulateResult.failed((int) code.asLong(), message);
        }
        return io.myotis.api.SimulateResult.unavailable(stringOrNull(o, "reason"));
    }

    /** Package-private test seam: access-list JSON (ABI 40) → the engine's
     *  outcome. The Rust side emits {@code {"status":"ok","accessList":[…],
     *  "gasUsed":N}} — plus {@code vmError} (and {@code revertDataHex} for a
     *  revert) when the run itself failed, which geth reports NEXT TO the list
     *  as its {@code error}; it is not a top-level {@code error}, the engine's
     *  failure envelope — / {@code {"status":"unavailable","reason"}} /
     *  {@code {"status":"infeasible","reason"}}. The permanent {@code {"error",
     *  "code":-32602}} envelope is REFUSED and a plain {@code {"error"}} throws,
     *  as for {@link #callDetailedFromJson}; an {@code ok} without its list or
     *  gas is shape drift and fails closed. */
    static io.myotis.api.AccessListResult accessListFromJson(String json) {
        JsonObject o = parseJsonObject(json, "createAccessList");
        String refusal = permanentRefusalOrNull(o);
        if (refusal != null) return io.myotis.api.AccessListResult.refused(refusal);
        throwIfError(o);
        try {
            String status = stringOrNull(o, "status");
            if ("ok".equals(status)) {
                var list = o.get("accessList");
                if (list == null || !list.isArray()) {
                    throw new EngineException("createAccessList JSON: status=ok without an accessList array");
                }
                var gasUsed = o.get("gasUsed");
                if (gasUsed == null || !gasUsed.isNumber()) {
                    throw new EngineException("createAccessList JSON: status=ok without a numeric gasUsed");
                }
                String payload = stringOrNull(o, "revertDataHex");
                return io.myotis.api.AccessListResult.ok(
                        list.toString(), gasUsed.asLong(), stringOrNull(o, "vmError"),
                        payload == null ? null : hexToBytes(payload));
            }
            if ("infeasible".equals(status)) {
                String reason = stringOrNull(o, "reason");
                if (reason == null || reason.isBlank()) {
                    throw new EngineException("createAccessList JSON: status=infeasible without a reason");
                }
                return io.myotis.api.AccessListResult.infeasible(reason);
            }
            return io.myotis.api.AccessListResult.unavailable(stringOrNull(o, "reason"));
        } catch (EngineException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new EngineException(
                    "malformed createAccessList JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /** Package-private test seam: estimateGas JSON → the engine's three-way outcome.
     *  The Rust side emits {@code {"status":"ok","gas":N}} /
     *  {@code {"status":"revert","dataHex"}} (ABI v23) / {@code {"status":
     *  "unavailable","reason"}}; a revert is a VERIFIED answer whose payload the
     *  host serves as the standard code-3 error. An executor refusal (ABI 33)
     *  arrives as the permanent {@code {"error","code":-32602}} envelope and is
     *  {@link io.myotis.api.EstimateResult.Status#REFUSED}, as for
     *  {@link #callDetailedFromJson}. {@code {"status":"infeasible","reason"}}
     *  (ABI 34) is {@link io.myotis.api.EstimateResult.Status#INFEASIBLE}: the
     *  transaction does not fit the caller's gas or funds, and {@code reason} is
     *  geth's message. */
    static io.myotis.api.EstimateResult estimateGasDetailedFromJson(String json) {
        JsonObject o = parseJsonObject(json, "estimateGas");
        String refusal = permanentRefusalOrNull(o);
        if (refusal != null) return io.myotis.api.EstimateResult.refused(refusal);
        throwIfError(o);
        String status = stringOrNull(o, "status");
        if ("revert".equals(status)) {
            try {
                return io.myotis.api.EstimateResult.reverted(hexToBytes(stringOrNull(o, "dataHex")));
            } catch (RuntimeException e) {
                throw new EngineException(
                        "malformed estimateGas JSON from the Rust engine: " + e.getMessage(), e);
            }
        }
        if ("infeasible".equals(status)) {
            String reason = stringOrNull(o, "reason");
            if (reason == null || reason.isBlank()) {
                throw new EngineException("estimateGas JSON: status=infeasible without a reason");
            }
            return io.myotis.api.EstimateResult.infeasible(reason);
        }
        if (!"ok".equals(status)) {
            return io.myotis.api.EstimateResult.unavailable(stringOrNull(o, "reason"));
        }
        Long gas = estimateGasFromJson(json);
        // estimateGasFromJson throws on ok-without-gas, so gas is non-null here.
        return io.myotis.api.EstimateResult.ok(gas);
    }

    /** Package-private test seam: estimateGas JSON → gas estimate (or null) without JNI.
     *  The legacy two-state view: a revert or unavailable outcome reads as null. */
    static Long estimateGasFromJson(String json) {
        JsonObject o = parseResultOrThrow(json, "estimateGas");
        // A revert / unavailable run has no estimate → null.
        if (!"ok".equals(stringOrNull(o, "status"))) return null;
        // status == "ok" MUST carry a numeric gas; a missing/non-numeric one is native
        // shape drift → fail closed (EngineException), not a silent "unavailable".
        try {
            var gas = o.get("gas");
            if (gas == null || gas.isNull()) {
                throw new EngineException("estimateGas JSON: status=ok without a numeric 'gas' field");
            }
            return gas.asLong();
        } catch (EngineException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new EngineException(
                    "malformed estimateGas JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /**
     * One verified 32-byte storage word at a RAW position (eth_getStorageAt), or
     * null when unverified. The value is left-padded to a full 32-byte word (a
     * zero/unset slot → 32 zero bytes). {@code position32Hex} is the 0x-hex 32-byte
     * position. Throws {@link EngineException} on a transport / not-running failure.
     */
    byte[] storageAtVerified(String hexAddress, String position32Hex, String block) {
        return storageValueFromJson(gated(() -> RustEngineNative.nativeGetStorageAtJson(
                handle, hexAddress, position32Hex, block)));
    }

    /**
     * Verified {@code eth_getProof} (ABI 46): the EIP-1186 result object JSON, or the
     * engine's {@code {"error"}} / {@code {"error","code":-32602}} envelope, passed
     * through for the router to classify. {@code keysJson} is the JSON array of
     * storage keys as the request carried them; {@code block} is held to the proof
     * pin rules (the verified head, a recent head or the finalized block, exactly — by
     * tag, number or, since ABI 47, block hash). Throws
     * {@link EngineException} on a transport / not-running failure.
     */
    String proofJson(String hexAddress, String keysJson, String block) {
        return gated(() -> RustEngineNative.nativeGetProofJson(handle, hexAddress, keysJson, block));
    }

    /**
     * Verified eth_getBlockByNumber: the block JSON object, the literal
     * {@code "null"} (a verified future/unknown block → eth null), or throws
     * {@link EngineException} when it can't verify (transport / not-running).
     * {@code blockTag} is an eth block selector ({@code "latest"} / 0x-hex number);
     * {@code fullTransactions} selects decoded tx objects over hashes.
     */
    String blockByNumberJson(String blockTag, boolean fullTransactions) {
        return blockJsonOrThrow(
                gated(() -> RustEngineNative.nativeGetBlockByNumberJson(
                        handle, blockTag, fullTransactions)));
    }

    /**
     * Verified eth_getTransactionReceipt: the receipt JSON object, the literal
     * {@code "null"} (a verified "not seen" — pending/unknown tx, the wallet keeps
     * polling), or throws {@link EngineException} when it can't verify (transport /
     * not-running). {@code txHashHex} is the 0x-hex 32-byte tx hash.
     */
    /**
     * The pending-tag nonce overlay: {@code max(minedNonce, our broadcast nonce + 1)}
     * while unmined+unexpired, identity otherwise. A negative native answer
     * (malformed input / not running) falls back to the plain mined nonce.
     */
    long pendingNonceOverlay(String addressHex, long minedNonce) {
        long overlaid = RustEngineNative.nativePendingNonceOverlay(handle, addressHex, minedNonce);
        return overlaid >= 0 ? overlaid : minedNonce;
    }

    String transactionReceiptJson(String txHashHex) {
        return receiptJsonOrThrow(
                gated(() -> RustEngineNative.nativeGetTransactionReceiptJson(handle, txHashHex)));
    }

    /**
     * Verified eth_getTransactionByHash: the tx JSON object, the literal
     * {@code "null"} (a verified "not seen" — unknown/pending tx), or throws
     * {@link EngineException} when it can't verify (transport / not-running /
     * an undecodable located tx). {@code txHashHex} is the 0x-hex 32-byte hash.
     */
    String transactionByHashJson(String txHashHex) {
        return transactionJsonOrThrow(
                gated(() -> RustEngineNative.nativeGetTransactionByHashJson(handle, txHashHex)));
    }

    /**
     * Verified eth_getBlockByHash: the block JSON object, the literal
     * {@code "null"} (a hash this engine never verified / reorged away — eth's
     * unknown-block null), or throws {@link EngineException} when it can't
     * verify. {@code blockHashHex} is the 0x-hex 32-byte hash;
     * {@code fullTransactions} selects decoded tx objects over hashes.
     */
    String blockByHashJson(String blockHashHex, boolean fullTransactions) {
        return blockJsonOrThrow(
                gated(() -> RustEngineNative.nativeGetBlockByHashJson(
                        handle, blockHashHex, fullTransactions)));
    }

    /**
     * The canonical block a block hash names (ABI 47, #641): {@code {"hash","number"}},
     * the literal {@code "null"} (no canonical block this engine holds now has that hash),
     * or throws {@link EngineException} when it cannot tell (transport / not-running /
     * an error envelope). Header only — no body, and the block need not have been served.
     */
    String resolveBlockHashJson(String blockHashHex) {
        return jsonObjectOrThrow(
                gated(() -> RustEngineNative.nativeResolveBlockHashJson(handle, blockHashHex)),
                "resolved block");
    }

    /**
     * Verified eth_getRawTransactionByHash (ABI 53, #715): the native answer as it came
     * — {@code "0x…"}, the {@code "null"} literal, or an error envelope (its permanent
     * {@code "code":-32602} kept for the router) — after the wake gate.
     */
    String rawTransactionByHashJson(String txHashHex) {
        return gated(() -> RustEngineNative.nativeGetRawTransactionByHashJson(handle, txHashHex));
    }

    /** Verified eth_getRawTransactionByBlock{Number,Hash}AndIndex (ABI 53, #715), passed
     *  through as {@link #rawTransactionByHashJson}. */
    String rawTransactionByBlockJson(String selector, long index) {
        return gated(() -> RustEngineNative.nativeGetRawTransactionByBlockJson(handle, selector, index));
    }

    /**
     * Verified eth_feeHistory: the result JSON object, or throws
     * {@link EngineException} when it can't verify (transport / not-running /
     * bad selector) — this method has no {@code "null"} literal case, but the
     * shared tri-state parse tolerates one harmlessly. {@code percentilesJson}
     * is a JSON array of reward percentiles, or empty to omit the reward matrix.
     */
    String feeHistoryJson(long blockCount, String newestBlockTag, String percentilesJson) {
        return feeHistoryJsonOrThrow(gated(() -> RustEngineNative.nativeFeeHistoryJson(
                handle, blockCount, newestBlockTag, percentilesJson)));
    }

    /** Package-private test seam: native feeHistory payload → JSON | throw. */
    static String feeHistoryJsonOrThrow(String json) {
        return jsonObjectOrThrow(json, "feeHistory");
    }

    /**
     * eth_getLogs over the opt-in watch-list index. Returns the native payload
     * VERBATIM — the log ARRAY on success, or the {@code {"error": ...}}
     * envelope (coverage / config detail) for the router to surface at -32000.
     * Only the lifecycle gate throws (not running / paused).
     */
    String getLogsJson(String filterJson) {
        return gated(() -> RustEngineNative.nativeGetLogsJson(handle, filterJson));
    }

    /** Install the log-index config (and apply its {@code unwatch} list); false = invalid config or gate down. */
    @Override
    public boolean setLogIndexConfig(String configJson) {
        try {
            return gated(() -> RustEngineNative.nativeSetLogIndexConfig(handle, configJson));
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Log-index status JSON ({"error":...} when the gate is down). */
    @Override
    public String logIndexStatusJson() {
        // NOT gated(): this is a STATUS PROBE the hosts poll every ~2s for the UI
        // snapshot (Android AndroidNodeBridge.snapshots, desktop DesktopNode). The
        // gated() wake-and-hold waits up to WAKE_WAIT_CAP_MS for readyForReads() on
        // a waking chain — a booting one's whole warm-up (and, before #312, ANY
        // unready chain: catching-up, STALE_ANCHOR-parked) — so gating here stalled
        // snapshot emissions ~90s per such chain and froze the whole UI at its
        // previous state (chains rendered "stopped" while running; the stale-anchor
        // consent appeared to do nothing). It also stamped activity + woke paused
        // stacks on every poll, fighting the idle-pause controller. The native
        // answers with {"error":...} on its own when the gate is down — exactly the
        // not-ready shape this method documents — so no readiness hold is needed.
        return RustEngineNative.nativeLogIndexStatusJson(handle);
    }

    /** Install the address-activity watch list (#691); false = refused or not running. */
    @Override
    public boolean setActivityWatch(String configJson) {
        // NOT gated(): a push must never wake a paused stack or wait out a warm-up.
        // A paused handle refuses it (false), and the host retries.
        try {
            return RustEngineNative.nativeSetActivityWatch(handle, configJson);
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Address-activity JSON ({"error":...} when the handle is not running). */
    @Override
    public String addressActivityJson(long afterBlock) {
        // NOT gated(), for the reason logIndexStatusJson gives: hosts poll it, and
        // the native answers {"error":...} on its own when the handle is not running.
        return RustEngineNative.nativeAddressActivityJson(handle, afterBlock);
    }

    /** Read-fetch shadow-cache counters ({"error":...} when the gate is down).
     *  NOT gated(), for the same status-probe reasons as logIndexStatusJson. */
    @Override
    public String readStatsJson() {
        return RustEngineNative.nativeReadStatsJson(handle);
    }

    /** Import portable log-index snapshots ({"ok":...} / {"error":...}). */
    @Override
    public String importLogIndexFiles(String pathsJson) {
        return gated(() -> RustEngineNative.nativeImportLogIndexFiles(handle, pathsJson));
    }

    /** Export the log index as a portable snapshot ({"ok":true} / {"error":...}). */
    @Override
    public String exportLogIndex(String path) {
        return gated(() -> RustEngineNative.nativeExportLogIndex(handle, path));
    }

    /**
     * Verified eth_getBlockReceipts: the receipts ARRAY JSON, the literal
     * {@code "null"} (verified unknown/future block or a never-verified hash),
     * or throws {@link EngineException} when it can't verify. {@code selector}
     * is a tag, a 0x-hex block number, or a 0x-32-byte block hash.
     */
    String blockReceiptsJson(String selector) {
        return blockReceiptsJsonOrThrow(
                gated(() -> RustEngineNative.nativeGetBlockReceiptsJson(handle, selector)));
    }

    /**
     * Package-private test seam: native payload → receipts ARRAY | "null" | throw.
     * Unlike the object seams the SUCCESS shape is a JSON array; an object is
     * either the error envelope (→ its message) or native shape drift (→ throw).
     */
    static String blockReceiptsJsonOrThrow(String json) {
        if (json == null || json.isBlank()) {
            throw new EngineException(
                    "blank blockReceipts JSON from the Rust engine (native failure?)");
        }
        if (json.equals("null")) return "null";
        com.eclipsesource.json.JsonValue v;
        try {
            v = Json.parse(json);
        } catch (RuntimeException e) {
            throw new EngineException(
                    "malformed blockReceipts JSON from the Rust engine: " + e.getMessage(), e);
        }
        if (v.isArray()) return json; // the verified receipts array
        if (v.isObject()) {
            var error = v.asObject().get("error");
            if (error != null && !error.isNull()) {
                throw new EngineException(error.isString() ? error.asString() : error.toString());
            }
        }
        throw new EngineException("blockReceipts JSON is neither an array nor an error object");
    }

    /** Package-private test seam: native block payload → block JSON | "null" | throw. */
    static String blockJsonOrThrow(String json) {
        return jsonObjectOrThrow(json, "block");
    }

    /** Package-private test seam: native tx payload → tx JSON | "null" | throw. */
    static String transactionJsonOrThrow(String json) {
        return jsonObjectOrThrow(json, "transaction");
    }

    /** Package-private test seam: native receipt payload → receipt JSON | "null" | throw. */
    static String receiptJsonOrThrow(String json) {
        return jsonObjectOrThrow(json, "receipt");
    }

    /** The shared tri-state native payload parse: a JSON object passes through, the
     *  {@code "null"} literal (a VERIFIED eth-null) passes through, an {@code error}
     *  object / blank / malformed payload throws {@link EngineException}. */
    private static String jsonObjectOrThrow(String json, String what) {
        if (json == null || json.isBlank()) {
            throw new EngineException(
                    "blank " + what + " JSON from the Rust engine (native failure?)");
        }
        // The eth-null literal (a verified negative) is not a JSON object; return it
        // before parsing so the router can emit a JSON null result.
        if (json.equals("null")) return "null";
        JsonObject o;
        try {
            o = Json.parse(json).asObject();
        } catch (RuntimeException e) {
            throw new EngineException(
                    "malformed " + what + " JSON from the Rust engine: " + e.getMessage(), e);
        }
        var error = o.get("error");
        if (error != null && !error.isNull()) {
            throw new EngineException(error.isString() ? error.asString() : error.toString());
        }
        return json; // the verified object
    }

    /** A verified fee suggestion — both values decimal-wei strings. */
    record FeeEstimate(String gasPriceWei, String maxPriorityFeePerGasWei) {}

    /** How long a fee estimate is reused so a paired gasPrice+maxPriorityFee poll
     *  shares one native call. The engine itself memoizes the estimate per
     *  anchored head and refreshes it in the background (#510), so a miss here is
     *  normally a memory hit there, not a verified fetch. */
    private static final long FEE_CACHE_TTL_NANOS = 3_000_000_000L; // 3s
    /** Value+timestamp in one volatile so a reader can't pair a fresh estimate with
     *  a stale stamp (or vice versa). Monotonic nanoTime — immune to wall-clock/NTP
     *  jumps that could otherwise expire the cache early or serve it too long. */
    private record CachedFee(FeeEstimate est, long atNanos) {}
    private volatile CachedFee cachedFee;

    /**
     * Verified fee suggestion, cached for {@link #FEE_CACHE_TTL_NANOS}. Throws
     * {@link EngineException} when it can't verify (transport / not-running) — the
     * error is never cached, so the next call retries.
     */
    FeeEstimate feeEstimate() {
        CachedFee c = cachedFee;
        if (c != null && System.nanoTime() - c.atNanos() < FEE_CACHE_TTL_NANOS) {
            // Still a host-visible read: stamp activity (and kick a wake) even on a
            // cache hit, so a fee-polling wallet keeps the idle timer honest.
            noteActivityAndWake();
            return c.est();
        }
        FeeEstimate est = feeFromJson(gated(() -> RustEngineNative.nativeFeeEstimateJson(handle)));
        cachedFee = new CachedFee(est, System.nanoTime());
        return est;
    }

    /** Package-private test seam: fee JSON → {@link FeeEstimate} without JNI. */
    static FeeEstimate feeFromJson(String json) {
        JsonObject o = parseResultOrThrow(json, "fee");
        String gas;
        String tip;
        try {
            // Field extraction only — a type-mismatched value (asString on a non-
            // string) is Rust-side shape drift → "malformed".
            gas = stringOrNull(o, "gasPriceWei");
            tip = stringOrNull(o, "maxPriorityFeePerGasWei");
        } catch (RuntimeException e) {
            throw new EngineException("malformed fee JSON from the Rust engine: " + e.getMessage(), e);
        }
        // Missing-field check OUTSIDE the try so its message isn't re-wrapped as
        // "malformed" by the catch (EngineException is a RuntimeException).
        if (gas == null || tip == null) {
            throw new EngineException("fee JSON missing gasPriceWei/maxPriorityFeePerGasWei");
        }
        return new FeeEstimate(gas, tip);
    }

    /**
     * Gossip a signed raw transaction: its 32-byte hash as
     * {@link io.myotis.api.SendResult.Status#SENT}, or (ABI 36, #531)
     * {@link io.myotis.api.SendResult.Status#REJECTED} with geth's reason for
     * one the engine refused before broadcasting it, or (ABI 44, #360)
     * {@link io.myotis.api.SendResult.Status#REFUSED} for bytes that are no
     * transaction it relays. Throws {@link EngineException} when no peer could
     * be reached. {@code rawTxHex} is the 0x-hex raw transaction.
     */
    io.myotis.api.SendResult sendRawTransactionDetailedVerified(String rawTxHex) {
        // Bytes that are no transaction are refused on the bytes alone (ABI 45, #360),
        // BEFORE the wake wait: a paused or starting node must not hold that permanent
        // refusal, or turn it into a retryable one when the resume fails. The send
        // runs the same gate again.
        String refusal = sendGateRefusalOrNull(RustEngineNative.nativeCheckRawTransactionJson(rawTxHex));
        if (refusal != null) return io.myotis.api.SendResult.refused(refusal);
        return sendResultFromJson(
                gated(() -> RustEngineNative.nativeSendRawTransactionJson(handle, rawTxHex)));
    }

    /** Package-private test seam: the send gate's JSON → its refusal, or null when the
     *  bytes may be sent ({@code {"ok":true}}) or the answer is no refusal (bad hex,
     *  shape drift) — the send itself then answers. */
    static String sendGateRefusalOrNull(String json) {
        try {
            return permanentRefusalOrNull(parseJsonObject(json, "checkRawTransaction"));
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * Package-private test seam: send-tx JSON → its outcome.
     * {@code {"status":"rejected","reason"}} is the engine's answer (geth's
     * txpool verdict, nothing broadcast); the permanent
     * {@code {"error","code":-32602}} envelope is REFUSED (ABI 44: no
     * transaction the engine relays, nothing broadcast); otherwise the hash, as
     * {@link #txHashFromJson} reads it (throwing on a plain error or a
     * malformed payload).
     */
    static io.myotis.api.SendResult sendResultFromJson(String json) {
        JsonObject o = parseJsonObject(json, "sendRawTransaction");
        String refusal = permanentRefusalOrNull(o);
        if (refusal != null) return io.myotis.api.SendResult.refused(refusal);
        if ("rejected".equals(stringOrNull(o, "status"))) {
            String reason = stringOrNull(o, "reason");
            // Fail closed on a reason-less refusal: the wallet would be told
            // nothing about why, and a retry might as well be offered.
            if (reason == null || reason.isBlank()) {
                throw new EngineException("send-tx JSON rejected without a reason");
            }
            return io.myotis.api.SendResult.rejected(reason);
        }
        return io.myotis.api.SendResult.sent(txHashFromJson(json));
    }

    /** Package-private test seam: send-tx JSON → the 32-byte tx hash (throws on error). */
    static byte[] txHashFromJson(String json) {
        JsonObject o = parseResultOrThrow(json, "sendRawTransaction");
        String hex;
        try {
            hex = stringOrNull(o, "txHash");
        } catch (RuntimeException e) {
            throw new EngineException("malformed send-tx JSON from the Rust engine: " + e.getMessage(), e);
        }
        // Missing-field check OUTSIDE the try so its message isn't re-wrapped.
        if (hex == null) {
            throw new EngineException("send-tx JSON missing txHash");
        }
        byte[] hash;
        try {
            hash = hexToBytes(hex);
        } catch (RuntimeException e) {
            throw new EngineException("malformed send-tx txHash hex: " + e.getMessage(), e);
        }
        // A tx hash is exactly 32 bytes — fail closed rather than return a short/long
        // array the caller (router → hexData) would silently mis-encode.
        if (hash.length != 32) {
            throw new EngineException("send-tx txHash is not 32 bytes: " + hash.length);
        }
        return hash;
    }

    /** Package-private test seam: storage-at JSON → verified 32-byte word (or null). */
    static byte[] storageValueFromJson(String json) {
        JsonObject o = parseResultOrThrow(json, "storage");
        try {
            if (stringOrNull(o, "verifyMethod") == null) return null; // unverified → can't answer
            // valueHex is the big-endian value (leading zeros stripped) or null when the
            // slot is zero/unset; eth_getStorageAt returns a full 32-byte word.
            return leftPad32(hexToBytes(stringOrNull(o, "valueHex")));
        } catch (RuntimeException e) {
            throw new EngineException("malformed storage JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /** 0x-hex (or null/"0x"/empty) → bytes; null/empty → an empty array.
     *  The engine library's Hex ({@code :myotis-engine-common}), not
     *  {@code java.util.HexFormat}: HexFormat needs Android API 34 (minSdk is
     *  29), and Hex keeps the strict ASCII parse contract. */
    private static byte[] hexToBytes(String hexOrNull) {
        if (hexOrNull == null) return new byte[0];
        return io.myotis.engines.common.Hex.parseHexPrefixed(hexOrNull);
    }

    /** Left-pad a big-endian value to a 32-byte word (a storage value is ≤ 32 bytes). */
    private static byte[] leftPad32(byte[] v) {
        if (v.length == 32) return v;
        if (v.length > 32) {
            throw new EngineException("storage value exceeds 32 bytes: " + v.length);
        }
        byte[] out = new byte[32];
        System.arraycopy(v, 0, out, 32 - v.length, v.length);
        return out;
    }

    private static StorageProofResult storageFromJson(String hexAddress, long slot, JsonObject o) {
        try {
        return new StorageProofResult(
                o.getString("addressHex", hexAddress),
                o.getLong("slot", slot),
                stringOrNull(o, "holderHex"),
                stringOrNull(o, "storageKeyHex"),
                stringOrNull(o, "storageKeyHashHex"),
                o.getBoolean("exists", false),
                stringOrNull(o, "valueHex"),
                stringOrNull(o, "valueDecimal"),
                o.getInt("slotsReturned", 0),
                stringOrNull(o, "storageRootHex"),
                stringList(o, "proofNodesHex"),
                o.getBoolean("storageProofValid", false),
                o.getBoolean("beaconSynced", false),
                o.getBoolean("beaconChainVerified", false),
                o.getBoolean("blsVerified", false),
                o.getLong("matchedBeaconSlot", -1L),
                stringOrNull(o, "verifyMethod"),
                stringOrNull(o, "failReason"),
                o.getLong("peerBlockNumber", 0L),
                o.getLong("finalizedBlockNumber", 0L),
                o.getLong("optimisticBlockNumber", 0L),
                o.getLong("finalizedSlot", 0L),
                o.getLong("optimisticSlot", 0L),
                o.getInt("maxHeaderChainGap", 0));
        } catch (RuntimeException e) {
            throw new EngineException("malformed storage JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /**
     * Parse a native verified-read payload. A {@code {"error": "..."}} object (a
     * transport / not-running / bad-input failure) becomes an {@link EngineException};
     * a null/blank/malformed payload likewise. A verification FAILURE is NOT an error —
     * it is a full result whose {@code failReason} is set, and is returned normally.
     */
    private static JsonObject parseResultOrThrow(String json, String what) {
        JsonObject o = parseJsonObject(json, what);
        throwIfError(o);
        return o;
    }

    /** The first half of {@link #parseResultOrThrow}: a null/blank/malformed
     *  payload throws, an error envelope is returned like any other object. */
    private static JsonObject parseJsonObject(String json, String what) {
        if (json == null || json.isBlank()) {
            throw new EngineException((json == null ? "null" : "blank") + " " + what
                    + " JSON from the Rust engine (native failure?)");
        }
        try {
            return Json.parse(json).asObject();
        } catch (RuntimeException e) {
            throw new EngineException(
                    "malformed " + what + " JSON from the Rust engine: " + e.getMessage(), e);
        }
    }

    /** The second half of {@link #parseResultOrThrow}: an {@code {"error": ...}}
     *  envelope becomes an {@link EngineException} carrying its message. */
    private static void throwIfError(JsonObject o) {
        var error = o.get("error");
        if (error != null && !error.isNull()) {
            // The Rust side always emits a string error, but tolerate a
            // structured value rather than throwing a raw library exception.
            throw new EngineException(error.isString() ? error.asString() : error.toString());
        }
    }

    /** JSON-RPC's "invalid params" code: the Rust engine's PERMANENT refusal. */
    private static final int INVALID_PARAMS = -32602;

    /**
     * The message of the engine's permanent refusal envelope,
     * {@code {"error": "...", "code": -32602}} ({@code eljson::invalid_params_json}),
     * or null for anything else: a result, a plain {@code {"error"}} (retryable,
     * the host's -32000), or an error with some other code. No retry can make
     * the refused request succeed, so the detailed call/estimate reads surface
     * it as REFUSED and the router serves -32602, never the retryable -32000 a
     * client would spin on (CLAUDE.md: a refusal is permanent).
     */
    private static String permanentRefusalOrNull(JsonObject o) {
        var error = o.get("error");
        var code = o.get("code");
        if (error == null || error.isNull() || code == null || !code.isNumber()
                || code.asDouble() != INVALID_PARAMS) {
            return null;
        }
        return error.isString() ? error.asString() : error.toString();
    }

    /** A JSON string field, or null when absent/JSON-null. */
    private static String stringOrNull(JsonObject o, String key) {
        var v = o.get(key);
        return (v == null || v.isNull()) ? null : v.asString();
    }

    /**
     * A JSON number field that may be null or absent, as a long; -1 when it is.
     * A present non-number throws, caught by the field-mapping try/catch as an
     * {@link EngineException}. Package-private: {@link RustEnsApi} reads the same
     * optional field.
     */
    static long longOrMinusOne(JsonObject o, String key) {
        var v = o.get(key);
        return (v == null || v.isNull()) ? -1L : v.asLong();
    }

    /**
     * A JSON string-array field as an unmodifiable List. An ABSENT field yields
     * an empty list (forward-compat with an older native that omits it), but a
     * PRESENT field that isn't a string array throws (via {@code asArray()} /
     * {@code asString()}) — caught by the field-mapping try/catch as an
     * {@link EngineException}, failing closed on Rust-side shape drift.
     */
    private static List<String> stringList(JsonObject o, String key) {
        var v = o.get(key);
        if (v == null || v.isNull()) return List.of();
        List<String> out = new java.util.ArrayList<>();
        v.asArray().forEach(e -> out.add(e.asString()));
        // Unmodifiable: these lists live inside immutable result records.
        return java.util.Collections.unmodifiableList(out);
    }

    @Override
    public HeadersResult getHeaders(long startBlock, int count) {
        throw new EngineException(NOT_AVAILABLE);
    }

    @Override
    public BlockResult getBlockVerified(long blockNumber) {
        throw new EngineException(NOT_AVAILABLE);
    }

    @Override
    public DialResult dialPeer(String host, int port, String pubkeyHex) {
        throw new EngineException(NOT_AVAILABLE);
    }
}
